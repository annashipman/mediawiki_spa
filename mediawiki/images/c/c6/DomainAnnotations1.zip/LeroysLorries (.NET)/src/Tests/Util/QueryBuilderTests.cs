using LeroysLorries.Model.Entities;
using LeroysLorries.Server;
using LeroysLorries.Tests.TestHelper;
using LeroysLorries.Util;
using NUnit.Framework;

namespace LeroysLorries.Tests.Util
{
    [TestFixture]
    class QueryBuilderTests
    {
        [Test]
        public void AddsConditionWithPlaceholderToPathAndParameterToList()
        {
            Country country = Mother.CreateCountry();
            QueryBuilder builder = new QueryBuilder(typeof(Region));
            builder.AppendCondition(new string[] {"Country"}, country);
            Query query = builder.GetQuery();

            Assert.AreEqual(typeof(Region), query.Type);
            Assert.AreEqual("Country={0}", query.Qualifier);
            Assert.AreEqual(1, query.Parameters.Length);
            Assert.AreSame(country, query.Parameters[0]);
        }

        [Test]
        public void CreatesDottedPath()
        {
            Country country = Mother.CreateCountry();
            QueryBuilder builder = new QueryBuilder(typeof(Warehouse));
            builder.AppendCondition(new string[] {"Region", "Country"}, country);
            Query query = builder.GetQuery();

            Assert.AreEqual("Region.Country={0}", query.Qualifier);
        }

        [Test]
        public void UsesThisKeywordForEmptyPath()
        {
            Country country = Mother.CreateCountry();
            QueryBuilder builder = new QueryBuilder(typeof(Warehouse));
            builder.AppendCondition(new string[0], country);
            Query query = builder.GetQuery();

            Assert.AreEqual("this={0}", query.Qualifier);
        }

        [Test]
        public void UsesAndKeywordToJoinConditions()
        {
            QueryBuilder builder = new QueryBuilder(typeof(PlannedTransfer));
            Warehouse warehouse = Mother.CreateWarehouse();
            builder.AppendCondition(new string[] { "Warehouse" }, warehouse);
            Period period = Mother.CreatePeriod(2006, 01);
            builder.AppendCondition(new string[] { "Period"}, period);
            Query query = builder.GetQuery();

            Assert.AreEqual("Warehouse={0} and Period={1}", query.Qualifier);
            Assert.AreEqual(2, query.Parameters.Length);
            Assert.AreSame(warehouse, query.Parameters[0]);
            Assert.AreSame(period, query.Parameters[1]);
        }
    }
}