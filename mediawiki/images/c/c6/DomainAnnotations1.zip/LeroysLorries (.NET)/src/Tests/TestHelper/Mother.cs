using LeroysLorries.Model.Entities;

namespace LeroysLorries.Tests.TestHelper
{
    class Mother
    {
        public static User CreateUser()
        {
            User user = new User();
            user.Name = "Test User";
            user.Country = CreateCountry();
            return user;
        }

        public static User CreatPlanner()
        {
            User user = CreateUser();
            user.AddRole(CreatePlannerRole());
            return user;
        }

        public static User CreateGlobalAdmin()
        {
            User user = CreateUser();
            user.AddRole(CreateGlobalAdminRole());
            return user;
        }

        public static User CreateCountryAdmin()
        {
            User user = CreateUser();
            user.AddRole(CreateCountryAdminRole());
            user.Country = CreateCountry();
            return user;
        }

        public static Role CreatePlannerRole()
        {
            Role plannerRole = new Role();
            plannerRole.Name = "Planner";
            plannerRole.RoleValue = RoleValue.Planner;
            return plannerRole;
        }

        public static Role CreateGlobalAdminRole()
        {
            Role adminRole = new Role();
            adminRole.Name = "Global Administrator";
            adminRole.RoleValue = RoleValue.GlobalAdmin;
            return adminRole;
        }

        public static Role CreateCountryAdminRole()
        {
            Role plannerRole = new Role();
            plannerRole.Name = "Country Administrator";
            plannerRole.RoleValue = RoleValue.CountryAdmin;
            return plannerRole;
        }

        public static Country CreateCountry()
        {
            Country country = new Country();
            country.Name = "Test Country";
            return country;
        }

        public static Region CreateRegion()
        {
            Region region = new Region();
            region.Name = "Test Region";
            region.Country = CreateCountry();
            region.Country.AddRegion(region);
            return region;
        }

        public static Region CreateRegion(Country country)
        {
            Region region = CreateRegion();
            country.AddRegion(region);
            region.Country = country;
            return region;
        }
        
        public static Warehouse CreateWarehouse()
        {
            Warehouse warehouse = new Warehouse();
            warehouse.Name = "Test Wareouse";
            warehouse.Region = CreateRegion();
            warehouse.Region.AddWarehouse(warehouse);
            return warehouse;
        }

        public static Period CreatePeriod(int year, int month)
        {
            return new Period(year, month);
        }
    }
}