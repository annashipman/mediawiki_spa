using System.Reflection;
using LeroysLorries.Model.Attributes;
using LeroysLorries.Model.Entities;
using LeroysLorries.Util;
using NUnit.Framework;

namespace LeroysLorries.Tests.Util
{
    [TestFixture]
    class ReflectionHelperTests
    {
        [Test]
        public void FindsFirstPropertyForGivenAttribute()
        {
            PropertyInfo prop = ReflectionHelper.GetPropertyWithAttribute(typeof(TestClass), typeof(PeriodSpecificationAttribute));
            Assert.AreEqual("Period", prop.Name, "Should have found Period property");
        }

        
        [Test]
        public void ReturnAttributeWhenPresentOnType()
        {
            DataClassificationAttribute attr = ReflectionHelper.GetAttribute<DataClassificationAttribute>(typeof(TestClass));
            Assert.AreEqual(DataClassificationValue.Transactional, attr.Classification);
        }


        [Test]
        public void ReturnsDataClassificationWhenPresentOnType()
        {
            DataClassificationValue classification = ReflectionHelper.GetDataClassification(typeof(TestClass));
            Assert.AreEqual(DataClassificationValue.Transactional, classification);
        }
        
    
        #region Helper class

        [DataClassification(DataClassificationValue.Transactional)]
        public class TestClass
        {
            [CountrySpecification]
            public Country Country
            {
                get { return null; }
            }

            [PeriodSpecification]
            public Period Period
            {
                get { return null; }
            }
        }

        #endregion
    }
}