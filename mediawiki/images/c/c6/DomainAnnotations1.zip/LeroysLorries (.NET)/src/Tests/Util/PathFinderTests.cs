using LeroysLorries.Model.Entities;
using LeroysLorries.Tests.TestHelper;
using LeroysLorries.Util;
using NUnit.Framework;

namespace LeroysLorries.Tests.Util
{
    [TestFixture]
    class PathFinderTests
    {
        [Test]
        public void ReturnsEmptyPathIfCorrectTypeIsPassedIn()
        {
            PathFinder<Country> finder = new PathFinder<Country>();
            string[] path = finder.GetPath(typeof(Country));

            Assert.AreEqual(0, path.Length, "Should return empty path");
        }


        [Test]
        public void ReturnsPropertyForDirectRelation()
        {
            PathFinder<Country> finder = new PathFinder<Country>();
            string[] path = finder.GetPath(typeof(Region));

            Assert.AreEqual(1, path.Length, "Should return property");
            Assert.AreEqual("Country", path[0], "Should return property relating to country");
        }


        [Test]
        public void ReturnsMultiplePropertiesForPath()
        {
            PathFinder<Country> finder = new PathFinder<Country>();
            string[] path = finder.GetPath(typeof(Warehouse));

            Assert.AreEqual(2, path.Length, "Should return all properties for path");
            Assert.AreEqual("Region", path[0], "Should return property relating to country");
            Assert.AreEqual("Country", path[1], "Should return property relating to country");
        }
        
        
        [Test]
        public void ReturnObjectIfItIsOfRightType()
        {
            PathFinder<Country> finder = new PathFinder<Country>();
            Country country = Mother.CreateCountry();
            Country result = finder.GetTargetObject(country);

            Assert.AreSame(country, result);
        }

        
        [Test]
        public void ReturnsObjectAtEndOfPath()
        {
            PathFinder<Country> finder = new PathFinder<Country>();
            Warehouse warehouse = Mother.CreateWarehouse();
            Country result = finder.GetTargetObject(warehouse);

            Assert.AreSame(warehouse.Region.Country, result);
        }

    }
}