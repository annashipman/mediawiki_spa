using System;
using System.Collections.Generic;
using LeroysLorries.Model.Entities;
using LeroysLorries.Server;
using NUnit.Framework;

namespace LeroysLorries.Tests.Server
{
    [TestFixture]
    class AuditorTests
    {
        private Auditor auditor;
        private User user;
        private DateTime timestamp;

        [SetUp]
        public void SetUp()
        {
            user = new User();
            timestamp = new DateTime(2006, 01, 01);
            auditor = new Auditor(user, timestamp);
        }

        [Test]
        public void CreatesAuditRecordForReferenceData()
        {
            Product product = new Product();
            product.Name = "Super Foo";
            Product snapshot = new Product();
            snapshot.Name = "Foo";

            List<AuditRecord> records = new List<AuditRecord>();
            auditor.CreateAuditRecords(product, snapshot, records);

            Assert.IsNotNull(records, "Should have returned list of records");
            Assert.AreEqual(1, records.Count, "Should have found one change");
            Assert.AreEqual("Changed Name from 'Foo' to 'Super Foo'", records[0].Description);
            Assert.AreEqual(timestamp, records[0].Timestamp);
            Assert.AreSame(user, records[0].Modifier);
        }

        [Test]
        public void HandlesNullAsOldValue()
        {
            Product product = new Product();
            product.Name = "Foo";
            Product snapshot = new Product();
            snapshot.Name = null;

            List<AuditRecord> records = new List<AuditRecord>();
            auditor.CreateAuditRecords(product, snapshot, records);

            Assert.AreEqual("Changed Name from '' to 'Foo'", records[0].Description);
        }

        [Test]
        public void HandlesNullAsNewValueAndIsEqualToOldNullValue()
        {
            Product product = new Product();
            product.Name = null;
            Product snapshot = new Product();
            snapshot.Name = null;

            List<AuditRecord> records = new List<AuditRecord>();
            auditor.CreateAuditRecords(product, snapshot, records);

            Assert.AreEqual(0, records.Count, "Should not have found change");
        }

        [Test]
        public void DoesNotCreateAuditRecordForTransactionalDataWithChanges()
        {
            Transfer transfer = new Transfer();
            transfer.PickupDate = new DateTime(2006, 01, 12);
            transfer.Quantity = 10;
            Transfer snapshot = new Transfer();
            transfer.PickupDate = new DateTime(2006, 01, 12);
            transfer.Quantity = 12;

            List<AuditRecord> records = new List<AuditRecord>();
            auditor.CreateAuditRecords(transfer, snapshot, records);

            Assert.IsNotNull(records, "Should have returned list");
            Assert.AreEqual(0, records.Count, "Should have added no record to list");
        }
    }
}