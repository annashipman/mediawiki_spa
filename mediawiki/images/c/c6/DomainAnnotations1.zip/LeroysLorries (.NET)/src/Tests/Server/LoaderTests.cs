using System;
using System.Collections.Generic;
using LeroysLorries.Model.Entities;
using LeroysLorries.Server;
using LeroysLorries.Tests.TestHelper;
using NUnit.Framework;

namespace LeroysLorries.Tests.Server
{
    [TestFixture]
    internal class LoaderTests
    {
        
        [Test]
        public void LoadsAllCountriesAndRegionsForGlobalAdmin()
        {
            FakeDataStoreForLoaderTests store = new FakeDataStoreForLoaderTests();
            Type[] types = new Type[] {typeof(Country), typeof(Region)};
            Loader loader = new Loader(store, types);

            User user = Mother.CreateGlobalAdmin();
            loader.LoadObjects(user, null);

            Assert.AreEqual(2, store.queries.Count);
            Assert.AreEqual(typeof(Country), store.queries[0].Type);
            Assert.AreEqual("", store.queries[0].Qualifier);
            Assert.AreEqual(typeof(Region), store.queries[1].Type);
            Assert.AreEqual("", store.queries[1].Qualifier);
        }

        [Test]
        public void DoesNotLoadTransactionalDataIfUserIsNotAPlanner()
        {
            FakeDataStoreForLoaderTests store = new FakeDataStoreForLoaderTests();
            Type[] types = new Type[] { typeof(Country), typeof(Region), typeof(PlannedTransfer) };
            Loader loader = new Loader(store, types);

            User user = Mother.CreateGlobalAdmin();
            loader.LoadObjects(user, null);

            Assert.AreEqual(2, store.queries.Count);
            Assert.AreEqual(typeof(Country), store.queries[0].Type);
            Assert.AreEqual(typeof(Region), store.queries[1].Type);
        }

        [Test]
        public void LoadsOnlyRelevantRegionsForPlanner()
        {
            FakeDataStoreForLoaderTests store = new FakeDataStoreForLoaderTests();
            Type[] types = new Type[] {typeof(Country), typeof(Region)};
            Loader loader = new Loader(store, types);

            User user = Mother.CreatPlanner();
            loader.LoadObjects(user, null);

            Assert.AreEqual(2, store.queries.Count);
            Assert.AreEqual(typeof(Country), store.queries[0].Type);
            Assert.AreEqual(typeof(Region), store.queries[1].Type);
            Assert.AreEqual("Country={0}", store.queries[1].Qualifier);
            Assert.AreEqual(user.Country, store.queries[1].Parameters[0]);
        }

        [Test]
        public void LoadOnlyRelevantTransactionalDataForPlanner()
        {
            FakeDataStoreForLoaderTests store = new FakeDataStoreForLoaderTests();
            Type[] types = new Type[] {typeof(PlannedTransfer)};
            Loader loader = new Loader(store, types);

            User user = Mother.CreatPlanner();
            Period period = new Period(2006, 1);
            loader.LoadObjects(user, period);

            Assert.AreEqual(1, store.queries.Count);
            Assert.AreEqual(typeof(PlannedTransfer), store.queries[0].Type);
            Assert.AreEqual("Origin.Region.Country={0} and Period={1}", store.queries[0].Qualifier);
            Assert.AreEqual(user.Country, store.queries[0].Parameters[0]);
            Assert.AreEqual(period, store.queries[0].Parameters[1]);
        }

        #region HelperClass

        public class FakeDataStoreForLoaderTests : IDataStore
        {
            public List<Query> queries = new List<Query>();

            public List<object> FetchObjects(Query query)
            {
                queries.Add(query);
                return new List<object>();
            }
        }

        #endregion
    }
}