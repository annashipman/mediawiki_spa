using LeroysLorries.Model.Entities;
using LeroysLorries.Tests.TestHelper;
using NUnit.Framework;

namespace LeroysLorries.Tests.Model
{
    [TestFixture]
    class UserTests
    {
        [Test]
        public void DeterminesRoleMembershipWithMultipleRoles()
        {
            User user = Mother.CreateUser();
            user.AddRole(Mother.CreateGlobalAdminRole());
            user.AddRole(Mother.CreatePlannerRole());

            bool found = user.HasRole(RoleValue.Planner);
            Assert.IsTrue(found, "Should have found planner role");
        }
    }
}