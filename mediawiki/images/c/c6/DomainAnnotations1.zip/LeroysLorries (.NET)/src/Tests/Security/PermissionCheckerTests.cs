using LeroysLorries.Model.Entities;
using LeroysLorries.Security;
using LeroysLorries.Tests.TestHelper;
using NUnit.Framework;

namespace LeroysLorries.Tests.Security
{
    [TestFixture]
    class PermissionCheckerTests
    {
        [Test]
        public void PlannerCanChangeTransactionalData()
        {
            User planner = Mother.CreatPlanner();
            PlannedTransfer transfer = new PlannedTransfer();

            PermissionChecker checker = new PermissionChecker();
            bool ok = checker.CanChangeObject(planner, transfer);

            Assert.IsTrue(ok);
        }

        
        [Test]
        public void GlobalAdminUsersCanChangeReferenceData()
        {
            User globalAdmin = Mother.CreateGlobalAdmin();
            Region region = Mother.CreateRegion();
            
            PermissionChecker checker = new PermissionChecker();
            bool ok = checker.CanChangeObject(globalAdmin, region);
            
            Assert.IsTrue(ok);
        }

        [Test]
        public void PlannerCannotChangeReferenceData()
        {
            User planner = Mother.CreatPlanner();
            Region region = Mother.CreateRegion();

            PermissionChecker checker = new PermissionChecker();
            bool ok = checker.CanChangeObject(planner, region);

            Assert.IsFalse(ok);
        }

        [Test]
        public void CountryAdminUsersCanChangeReferenceDataForTheirCountry()
        {
            User countryAdmin = Mother.CreateCountryAdmin();
            Region region = Mother.CreateRegion(countryAdmin.Country);

            PermissionChecker checker = new PermissionChecker();
            bool ok = checker.CanChangeObject(countryAdmin, region);

            Assert.IsTrue(ok);
        }

        [Test]
        public void CountryAdminUsersCannotChangeReferenceDataForOtherCountries()
        {
            User countryAdmin = Mother.CreateCountryAdmin();
            Region region = Mother.CreateRegion(Mother.CreateCountry());

            PermissionChecker checker = new PermissionChecker();
            bool ok = checker.CanChangeObject(countryAdmin, region);

            Assert.IsFalse(ok);
        }

       
    }
}