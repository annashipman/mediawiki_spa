using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Reference)]
    public class Warehouse
    {
        private string name;
        private Region region;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        [CountrySpecification]
        public Region Region
        {
            get { return region; }
            set { region = value; }
        }
    }
}