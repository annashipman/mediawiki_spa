using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Reference)]
    public class Product
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}