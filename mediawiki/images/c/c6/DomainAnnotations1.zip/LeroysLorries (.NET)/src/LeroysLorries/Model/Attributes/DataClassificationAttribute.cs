using System;

namespace LeroysLorries.Model.Attributes
{
    public enum DataClassificationValue
    {
        Reference,
        Transactional,
        Audit,
        Configuration
    }

    [AttributeUsage(AttributeTargets.Class)]
    public class DataClassificationAttribute : Attribute
    {
        private DataClassificationValue classification;

        public DataClassificationAttribute(DataClassificationValue classification)
        {
            this.classification = classification;
        }

        public DataClassificationValue Classification
        {
            get { return classification; }
        }
    }
}