using System;
using System.Collections.Generic;
using System.Reflection;

namespace LeroysLorries.Util
{
    public class PathFinder<T>
    {
        private Type attrType;

        public PathFinder()
        {
            string typeName = "LeroysLorries.Model.Attributes." + typeof(T).Name + "SpecificationAttribute";
            if((attrType = Type.GetType(typeName)) == null)
                throw new ArgumentException(String.Format("No specification attribute for type {0}. ", typeof(T).FullName));
        }

        public string[] GetPath(Type type)
        {
            List<string> path = new List<string>();
            if(FollowPath(type, path) == false)
                throw new ArgumentException(String.Format("Cannot reach {0} from {1}", typeof(T).FullName, type));
            return path.ToArray();
        }

        private bool FollowPath(Type type, List<string> path)
        {
            if(type == typeof(T))
                return true;

            PropertyInfo prop = ReflectionHelper.GetPropertyWithAttribute(type, attrType);
            if(prop == null)
                return false;

            path.Add(prop.Name);
            return FollowPath(prop.PropertyType, path);
        }

        public T GetTargetObject(object anObject)
        {
            if(anObject.GetType() == typeof(T))
                return (T)anObject;

            PropertyInfo propInfo = ReflectionHelper.GetPropertyWithAttribute(anObject.GetType(), attrType);
            object nextObject = ReflectionHelper.GetPropertyValue(anObject, propInfo.Name);
            return GetTargetObject(nextObject);
        }
    }
    
}