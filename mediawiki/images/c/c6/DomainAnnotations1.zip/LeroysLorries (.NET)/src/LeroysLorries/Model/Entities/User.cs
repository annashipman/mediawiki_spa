using System.Collections.Generic;

namespace LeroysLorries.Model.Entities
{
    public class User
    {
        private string name;
        private Country country;
        private List<Role> roles;

        public User()
        {
            roles = new List<Role>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        public Country Country
        {
            get { return country; }
            set { country = value; }
        }

        public List<Role> Roles
        {
            get { return roles; }
        }

        public void AddRole(Role role)
        {
            roles.Add(role);
        }

        public void RemoveRole(Role role)
        {
            roles.Remove(role);
        }

        public bool HasRole(RoleValue roleValue)
        {
            foreach(Role r in roles)
            {
                if(r.RoleValue == roleValue)
                    return true;
            }
            return false;
        }
    }
}