using System;
using System.Collections.Generic;
using LeroysLorries.Model.Attributes;
using LeroysLorries.Model.Entities;
using LeroysLorries.Util;

namespace LeroysLorries.Server
{
    public class Loader
    {
        private IDataStore store;
        private Type[] types;

        public Loader(IDataStore store, Type[] types)
        {
            this.types = types;
            this.store = store;
        }

        public List<object> LoadObjects(User user, Period period)
        {
            List<object> allObjects = new List<object>();
            foreach(Type t in types)
            {
                if(ShouldLoad(t, user))
                {
                    Query query = CreateQuery(t, user, period);
                    List<object> result = store.FetchObjects(query);
                    allObjects.AddRange(result);
                }
            }
            return allObjects;
        }

        private bool ShouldLoad(Type type, User user)
        {
            DataClassificationValue classification = ReflectionHelper.GetDataClassification(type);
            if(classification == DataClassificationValue.Transactional)
            {
                return user.HasRole(RoleValue.Planner);
            }
            return true;
        }

        private Query CreateQuery(Type type, User user, Period period)
        {
            QueryBuilder builder = new QueryBuilder(type);

            if(user.HasRole(RoleValue.GlobalAdmin) == false)
            {
                PathFinder<Country> finder = new PathFinder<Country>();
                string[] path = finder.GetPath(type);
                builder.AppendCondition(path, user.Country);
            }
            if(ReflectionHelper.GetDataClassification(type) == DataClassificationValue.Transactional)
            {
                PathFinder<Period> finder = new PathFinder<Period>();
                string[] path = finder.GetPath(type);
                builder.AppendCondition(path, period);
            }

            return builder.GetQuery();
        }
    }
}