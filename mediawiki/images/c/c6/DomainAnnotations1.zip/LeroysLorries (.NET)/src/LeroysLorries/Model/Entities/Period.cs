using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Transactional)]
    public class Period
    {
        private int year;
        private int month;

        public Period(int year, int month)
        {
            this.year = year;
            this.month = month;
        }
        
        public int Year
        {
            get { return year; }
        }

        public int Month
        {
            get { return month; }
        }
    }
}