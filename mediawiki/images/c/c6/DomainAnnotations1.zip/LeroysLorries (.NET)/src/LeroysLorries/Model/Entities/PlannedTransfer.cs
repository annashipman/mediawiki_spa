using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Transactional)]
    public class PlannedTransfer
    {
        private Warehouse origin;
        private Warehouse destination;
        private Product product;
        private Period period;
        private int quantity;

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        [CountrySpecification]
        public Warehouse Origin
        {
            get { return origin; }
            set { origin = value; }
        }

        public Warehouse Destination
        {
            get { return destination; }
            set { destination = value; }
        }

        public Product Product
        {
            get { return product; }
            set { product = value; }
        }

        [PeriodSpecification]
        public Period Period
        {
            get { return period; }
            set { period = value; }
        }
    }
}