using System;

namespace LeroysLorries.Server
{
    public class Query
    {
        private Type type;
        private string qualifier;
        private object[] parameters;

        public Query(Type type, string qualifier, params object[] parameters)
        {
            this.type = type;
            this.qualifier = qualifier;
            this.parameters = parameters;
        }

        public Type Type
        {
            get { return type; }
        }

        public string Qualifier
        {
            get { return qualifier; }
        }

        public object[] Parameters
        {
            get { return parameters; }
        }
    }
}