using System;
using System.Collections.Generic;
using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Reference)]
    public class Region
    {
        private String name;
        private Country country;
        private List<Warehouse> warehouses;

        public Region()
        {
            warehouses = new List<Warehouse>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        [CountrySpecification]
        public Country Country
        {
            get { return country; }
            set { country = value; }
        }

        public List<Warehouse> Warehouses
        {
            get { return warehouses; }
        }

        public void AddWarehouse(Warehouse warehouse)
        {
            warehouses.Add(warehouse);
        }

        public void RemoveWarehouse(Warehouse warehouse)
        {
            warehouses.Remove(warehouse);
        }
    }
}