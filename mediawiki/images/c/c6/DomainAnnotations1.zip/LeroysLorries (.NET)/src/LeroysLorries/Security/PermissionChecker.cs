using LeroysLorries.Model.Attributes;
using LeroysLorries.Model.Entities;
using LeroysLorries.Util;

namespace LeroysLorries.Security
{
    public class PermissionChecker
    {
        public bool CanChangeObject(User user, object anObject)
        {
            DataClassificationValue classification = ReflectionHelper.GetDataClassification(anObject.GetType());
            switch(classification)
            {
                case DataClassificationValue.Reference:

                    if(user.HasRole(RoleValue.GlobalAdmin))
                    {
                        return true;
                    }

                    #region Country admin

                    if(user.HasRole(RoleValue.CountryAdmin))
                    {
                        return (FindCountry(anObject) == user.Country);
                    }

                    #endregion

                    return false;

                default:
                    return true;
            }
        }

        private Country FindCountry(object anObject)
        {
            return new PathFinder<Country>().GetTargetObject(anObject);
        }
    }
}