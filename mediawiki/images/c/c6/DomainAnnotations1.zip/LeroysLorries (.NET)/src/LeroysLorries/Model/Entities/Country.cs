using System.Collections.Generic;
using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Reference)]
    public class Country
    {
        private string name;
        private List<Region> regions;

        public Country()
        {
            regions = new List<Region>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        public List<Region> Regions
        {
            get { return regions; }
        }

        public void AddRegion(Region region)
        {
            regions.Add(region);
        }

        public void RemoveRegion(Region region)
        {
            regions.Remove(region);
        }
    }
}