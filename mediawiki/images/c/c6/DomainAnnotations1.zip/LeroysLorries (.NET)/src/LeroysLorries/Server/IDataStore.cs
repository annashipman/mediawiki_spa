using System.Collections.Generic;

namespace LeroysLorries.Server
{
    public interface IDataStore
    {
        List<object> FetchObjects(Query query);
    }
}