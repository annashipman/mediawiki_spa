using System;
using System.Collections.Generic;
using System.Reflection;
using LeroysLorries.Model.Attributes;
using LeroysLorries.Model.Entities;
using LeroysLorries.Util;

namespace LeroysLorries.Server
{
    public class Auditor
    {
        private User user;
        private DateTime timestamp;

        public Auditor(User user, DateTime timestamp)
        {
            this.user = user;
            this.timestamp = timestamp;
        }

        public void CreateAuditRecords(object modified, object snapshot, List<AuditRecord> records)
        {
            Type type = modified.GetType();

            if(ShouldAudit(type) == false)
                return;
            
            PropertyInfo[] properties = type.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly);
            foreach(PropertyInfo p in properties)
            {
                object oldValue = ReflectionHelper.GetPropertyValue(snapshot, p.Name);
                object newValue = ReflectionHelper.GetPropertyValue(modified, p.Name);

                if(AreEqual(oldValue, newValue) == false)
                {
                    string desc = String.Format("Changed {0} from '{1}' to '{2}'", p.Name, oldValue, newValue);
                    records.Add(new AuditRecord(desc, user, timestamp));
                }
            }
            return;
        }

        private bool ShouldAudit(Type type)
        {
            DataClassificationValue classification = ReflectionHelper.GetDataClassification(type);
            return classification == DataClassificationValue.Reference;
        }

        private bool AreEqual(object a, object b)
        {
            if(a == null)
                return (b == null);
            return a.Equals(b);
        }
    }
}