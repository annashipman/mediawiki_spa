using System;
using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Transactional)]
    public class Transfer
    {
        private PlannedTransfer plannedTransfer;
        private DateTime pickupDate;
        private int quantity;

        public DateTime PickupDate
        {
            get { return pickupDate; }
            set { pickupDate = value; }
        }

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        [PeriodSpecification]
        [CountrySpecification]
        public PlannedTransfer PlannedTransfer
        {
            get { return plannedTransfer; }
            set { plannedTransfer = value; }
        }
    }
}