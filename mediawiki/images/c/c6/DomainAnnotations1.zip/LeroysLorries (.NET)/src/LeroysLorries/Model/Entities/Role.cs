using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    public enum RoleValue
    {
        Planner,
        CountryAdmin,
        GlobalAdmin
    }

    [DataClassification(DataClassificationValue.Configuration)]
    public class Role
    {
        private string name;
        private RoleValue roleValue;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public RoleValue RoleValue
        {
            get { return roleValue; }
            set { roleValue = value; }
        }
    }
}