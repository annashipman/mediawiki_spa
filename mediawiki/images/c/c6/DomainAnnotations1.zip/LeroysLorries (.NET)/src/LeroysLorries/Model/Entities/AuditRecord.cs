using System;
using System.Collections.Generic;
using System.Text;
using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Model.Entities
{
    [DataClassification(DataClassificationValue.Audit)]
    public class AuditRecord
    {
        private object description;
        private User modifier;
        private DateTime timestamp;

        public AuditRecord(String description, User modifier, DateTime timestamp)
        {
            this.description = description;
            this.modifier = modifier;
            this.timestamp = timestamp;
        }

        public object Description
        {
            get { return description; }
        }

        public User Modifier
        {
            get { return modifier; }
        }

        public DateTime Timestamp
        {
            get { return timestamp; }
        }
    }
}
