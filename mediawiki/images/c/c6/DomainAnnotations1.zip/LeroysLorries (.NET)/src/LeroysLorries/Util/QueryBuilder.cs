using System;
using System.Collections.Generic;
using System.Text;
using LeroysLorries.Server;

namespace LeroysLorries.Util
{
    public class QueryBuilder
    {
        private Type type;
        private StringBuilder qualifier;
        private List<object> parameters;

        public QueryBuilder(Type type)
        {
            this.type = type;
            qualifier = new StringBuilder();
            parameters = new List<object>();
        }

        public Query GetQuery()
        {
            return new Query(type, qualifier.ToString(), parameters.ToArray());
        }

        public void AppendCondition(string[] path, object parameter)
        {
            string qpath = ConvertToQueryPath(path);
            if(qualifier.Length > 0)
                qualifier.Append(" and ");
            qualifier.AppendFormat("{0}={{{1}}}", qpath, parameters.Count);
            parameters.Add(parameter);
        }

        protected string ConvertToQueryPath(string[] path)
        {
            if(path.Length == 0)
                path = new string[] {"this"};
            return String.Join(".", path);
        }
    }
}