using System;
using System.Globalization;
using System.Reflection;
using LeroysLorries.Model.Attributes;

namespace LeroysLorries.Util
{
    public class ReflectionHelper
    {
        public static PropertyInfo GetPropertyWithAttribute(Type classToCheck, Type attributeType)
        {
            PropertyInfo[] properties = classToCheck.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly);
            foreach (PropertyInfo prop in properties)
            {
                if (prop.IsDefined(attributeType, true))
                    return prop;
            }
            return null;
        }

        public static T GetAttribute<T>(Type classToCheck)
        {
            object[] attributes = classToCheck.GetCustomAttributes(typeof(T), true);
            if (attributes.Length == 0)
                throw new ArgumentException(String.Format("{0} does not have {1}.", classToCheck.FullName, typeof(T).FullName));
            return (T)attributes[0];
        }

        public static DataClassificationValue GetDataClassification(Type classToCheck)
        {
            DataClassificationAttribute attr = GetAttribute<DataClassificationAttribute>(classToCheck);
            return attr.Classification;
        }
        
        public static void SetPropertyValue(object obj, string propName, object propValue)
        {
            try
            {
                BindingFlags bflags = BindingFlags.SetProperty | BindingFlags.Public | BindingFlags.Instance;
                obj.GetType().InvokeMember(propName, bflags, null, obj, new object[] {propValue}, CultureInfo.InvariantCulture);
            }
            catch(MissingMethodException e)
            {
                BindingFlags bflags = BindingFlags.SetProperty | BindingFlags.Public | BindingFlags.Instance;
                // maybe it was a mismatch on signature, i.e. right name but wrong type
                MemberInfo[] mi = obj.GetType().GetMember(propName, bflags);
                if(mi.Length == 0)
                    throw new InvalidPropertyException(
                        String.Format("{0} is not a valid property for class {1}", propName, obj.GetType()), e);
                // it was, pick the first property and try to convert value to its type
                propValue = Convert.ChangeType(propValue, ((PropertyInfo)mi[0]).PropertyType);
                obj.GetType().InvokeMember(propName, bflags, null, obj, new object[] {propValue}, CultureInfo.InvariantCulture);
            }
        }

        public static object GetPropertyValue(object obj, string propName)
        {
            try
            {
                BindingFlags bflags = BindingFlags.GetProperty | BindingFlags.Public | BindingFlags.Instance;
                return obj.GetType().InvokeMember(propName, bflags, null, obj, null, CultureInfo.InvariantCulture);
            }
            catch(MissingMethodException e)
            {
                throw new InvalidPropertyException(
                    String.Format("{0} is not a valid property for class {1}", propName, obj.GetType()), e);
            }
        }
    }
}