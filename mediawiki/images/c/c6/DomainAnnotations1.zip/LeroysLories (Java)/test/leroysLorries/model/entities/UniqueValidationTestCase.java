package leroysLorries.model.entities;

import junit.framework.TestCase;
import leroysLorries.model.entities.validation.UniqueValidator;
import leroysLorries.model.entities.validation.ValidationException;

public class UniqueValidationTestCase extends TestCase {

	public void testNoExceptionWillBeThrownSinceThereAreNoDuplicateNames(){
		Country country = new Country("UK");

		Region region1 = new Region("South", country);
		Region region2 = new Region("North", country);
	
		UniqueValidator validator = new UniqueValidator();
		
		validator.validate(region1);		
	}
	
	public void testWillFailIfTwoRegionsWithinACountryHaveTheSameName(){
		Country country = new Country("UK");

		Region region1 = new Region("North", country);
		Region region2 = new Region("North", country);
	
		UniqueValidator validator = new UniqueValidator();
		
		try{
			validator.validate(region1);
			fail();
		}catch(ValidationException e){
			
		}
		
	}
}
