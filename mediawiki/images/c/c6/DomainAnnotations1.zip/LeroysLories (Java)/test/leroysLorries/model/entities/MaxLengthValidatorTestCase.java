package leroysLorries.model.entities;

import junit.framework.TestCase;
import leroysLorries.model.entities.validation.MaxLengthValidator;
import leroysLorries.model.entities.validation.ValidationException;
import leroysLorries.model.entities.validation.Validator;

public class MaxLengthValidatorTestCase extends TestCase {

	public void testWillDoNothingIfNameIsCorrectLength(){
		Country country = new Country("ok length");
		Validator validator = new MaxLengthValidator();
		validator.validate(country);		
	}
	
	public void testWillThrowValidationExceptionIfNameIsTooLong(){
		Country country = new Country("this is a name that is longer than it should be");
		Validator validator = new MaxLengthValidator();
		try{
			validator.validate(country);
			fail();
		}catch(ValidationException valEx){}
	}
}
