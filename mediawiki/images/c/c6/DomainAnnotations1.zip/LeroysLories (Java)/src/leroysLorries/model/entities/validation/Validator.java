package leroysLorries.model.entities.validation;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;


public abstract class Validator {

	public void validate(Object obj) throws ValidationException {
		Class clss = obj.getClass();
		for(Method method : clss.getMethods()){
			if (method.isAnnotationPresent(getAnnotationType())){
				validateMethod(obj, method, method.getAnnotation(getAnnotationType()));
			}
		}
	}

	protected abstract Class getAnnotationType();
	protected abstract void validateMethod(Object obj, Method method, Annotation annotation);
}