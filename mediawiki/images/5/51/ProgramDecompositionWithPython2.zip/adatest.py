from ada import entry, dispatch, RendezVousError

@dispatch
def consumer():

    # declaration of entries
    class begin(entry): pass
    class other(entry): pass
    class end(entry): pass
    class notimplemented(entry): pass

    while True:
        # Ada like accept statements, dispatched by Exception mechanism
        try: yield

        except begin, (msg,):
            print "Executing entry 'begin' with args:", msg

        except other, (arg1, arg2):
            print "Executing entry 'other' with args:",  arg1, arg2

        except end, (arg,):
            print "Executing entry 'end' with args:",  arg

        else:
            print 'An exceptional situation has happened'

c = consumer()

# some Ada-like entry calls
c.begin(10)
c.end('a')
c.other('arg1', 'arg2')
c.send('aa')
try:
    c.notexisting()
    assert False
except AttributeError:
    pass
try:
    c.notimplemented()
    assert False
except RendezVousError, e:
    assert "Not ready for rendez-vous on 'notimplemented'" == str(e), e
