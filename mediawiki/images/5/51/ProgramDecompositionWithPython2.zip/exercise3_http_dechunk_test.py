# SPA 2008
# Session: "Program Decomposition With Python 2.5 Generators"
# Erik Groeneveld, erik@cq2.nl

from unittest import TestCase, main
from re import compile as compileRe, match as matchRe
from compose import compose
from types import GeneratorType
from util import collector

# This exercise deals with a more realistic problem, namely
# the dechunking of HTTP chunked-mode messages.
# From HTTP 1.1 spec:
CRLF = '\r\n'
Chunk_Size = '(?P<ChunkSize>[0-9a-fA-F]+)'
Chunk_Size_Line = Chunk_Size + CRLF
CHUNK_SIZE_LINE = compileRe(Chunk_Size_Line)

def readWhileRe(regexp):
    match = None
    message = ''
    while not match:
        message += yield
        match = matchRe(regexp, message)
    raise StopIteration(match, message[match.end():])

def readBytes(bytes):
    message = yield
    while len(message) < bytes:
        message += yield
    raise StopIteration(message[:bytes], message[bytes:])

def dechunk(next):
    while True:
        match = yield readWhileRe('(?P<ChunkSize>[0-9a-fA-F]+)\r\n')
        chunkSize = int("0x" + match.groupdict()['ChunkSize'], 16)
        chunk = yield readBytes(chunkSize)
        next.send(chunk)
        yield readBytes(len(CRLF))

data = []
dechunker = compose(dechunk(collector(data)))
dechunker.next()

class DechunkTest(TestCase):

    def testOneMessageEqualsOneChunk(self):
        networkMessage = '9\r\n123456789\r\n' # equals one chunk
        dechunker.send(networkMessage)
        self.assertEquals('123456789', data.pop())
        networkMessage = '3\r\nabc\r\n' # equals one chunk
        dechunker.send(networkMessage)
        self.assertEquals('abc', data.pop())

    def testTwoMessagesForOneChunk(self):
        networkMessage0 = 'A\r\n012345' # first part of chunk
        networkMessage1 = '6789\r\n' # second half of chunk
        dechunker.send(networkMessage0)
        dechunker.send(networkMessage1)
        self.assertEquals('0123456789', data.pop())

    def testOneMessageTwoChunks(self):
        networkMessage0 = 'B\r\nWhatIsThis?\r\n8\r\n87654321\r\n' # two chunks
        dechunker.send(networkMessage0)
        self.assertEquals('87654321', data.pop())
        self.assertEquals('WhatIsThis?', data.pop())

    def testOneMessageWithLastChunk(self):
        networkMessage0 = '9\r\n123456789\r\n0\r\n\r\n' # two chunks
        dechunker.send(networkMessage0)
        self.assertEquals('', data.pop())
        self.assertEquals('123456789', data.pop())

main()