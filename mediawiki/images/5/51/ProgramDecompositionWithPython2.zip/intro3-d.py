from util import collector, randomchars, autostart
from sys import stdout
from types import GeneratorType


# Exercise 2 -step 4
# Make it accept not single chars but chunks (strings) of chars
# (Jackson Boundary Clash)


# Exercise 3 - HTTP chunked mode

# Exercise 4 - Jackson Backtracking
# Extend exercise 2 such that it sends H-B combinations to the first pipeline and H-B-B blocks to another



