from util import collector, randomchars, autostart
from sys import stdout
from types import GeneratorType


# Exercise 2 -step 3
# Safeguard the extracted method agains endless searching:
# Make findSubstring raise OverflowError
def findSubstring(terminator, maxLenght):
    substring = ''
    char = yield
    while char != terminator:
        substring += char
        char = yield
    if len(substring) > maxLenght:
        raise OverflowError()
    raise StopIteration(substring)

# Catch it and translate it to a proper error message

def findSubStringStartingWithHandB(next):
    try:
        yield findSubstring('h', 10)
    except OverflowError:
        raise Exception('Too much garbage')
    while True:
        substring = yield findSubstring('b', 999)
        next.send(substring)
        substring = yield findSubstring('h', 999)
        next.send(substring)

@autostart
def compose(aGenerator):
    message = None
    while True:
        response = aGenerator.send(message)
        if type(response) == GeneratorType:
            generator = response
            message = None
            while True:
                try:
                    response = generator.send(message)
                    message = yield response
                except StopIteration, e:
                    message = e.args[0]
                    break
                except Exception, e:
                    aGenerator.throw(e)
        else:
            message = yield response




def testit():
    print '\nProcessing:'
    results = []
    pipeline = compose(findSubStringStartingWithHandB(collector(results)))
    for i, letter in zip(xrange(100), randomchars()):
        if letter in ['h', 'b']:
            stdout.write('>')
        stdout.write(letter)
        pipeline.send(letter)
    print '\nResults:'
    for line in results:
        stdout.write(line+' ')
    print


testit()