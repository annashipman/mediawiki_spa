# Intro for exercise 2 - step 1
# Create a filter that finds an 'H', then concatenates until the next 'B', then concatenates until the next 'H', and so on.  This is roughly equivalent to a practical problem: finding a header and body in a data stream.

# JSP: Garbage ( Header Body ) *

# Hits:
# create a pipeline that accepts letters
# do not try to extract duplicate code
# test visually like:

from sys import stdout
from util import randomchars, collector, feed, autostart

def testit():
    print '\nProcessing:'
    results = []
    pipeline = compose(findSubStringStartingWithHandB(collector(results)))
    pipeline.next()
    for i, letter in zip(xrange(100), randomchars()):
        if letter in ['h', 'b']:
            stdout.write('>')
        stdout.write(letter)
        pipeline.send(letter)
    print '\nResults:'
    for line in results:
        stdout.write(line+' ')
    print

def readUntil(terminal):
    substring = ''
    char = yield
    while char != terminal:
        substring += char
        char = yield
    raise StopIteration(substring)

from types import GeneratorType

def compose(aGenerator):
    message = None
    while True:
        response = aGenerator.send(message)
        if type(response) == GeneratorType:
            generator = response
            message = None
            while True:
                try:
                    response = generator.send(message)
                    message = yield response
                except StopIteration, exValue:
                    message = exValue.args[0]
                    break
        else:
            message = yield response

@autostart
def findSubStringStartingWithHandB(next):
    yield readUntil('h')
    while True:
        substring = yield readUntil('b')
        next.send(substring)
        substring = yield readUntil('h')
        next.send(substring)


testit()