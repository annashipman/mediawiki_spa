def power(n, i):
    return n**i

print 'Power of 2:', power(2, 10)

def powers(n):
    i = 0
    while True:
        i += 1
        yield n**i

print 'More power:'
p = powers(2)       # args binding
print p.next()      # start and first result
print p.next()      # next result


def powers(n):
    i = 0
    while True:
        i += 1
        message = yield n**i
        if message:
            i = message

p = powers(2)       # args binding
print p.next()      # start and first result
print p.send(10)    # continue with 10 and get next result
print p.next()      # next result


def powers(n):
    i = 0
    for x in range(2):
        i += 1
        try:
            message = yield n**i
            if message:
                i = message
        except GeneratorExit:
            return
            #raise
            #raise Exception('STOP')

print 'And still some more:'
p = powers(2)                   # args binding
print p.next()                  # init, first value
#print p.next()                  # second value
#print p.next()                  # StopIteration
print p.close()                 # did it stop?
#print p.next()                  # Yes!


class LastNumber: pass

def powers(n):
    i = 0
    while True:
        i += 1
        try:
            message = yield n**i
            if message:
                i = message
        except LastNumber:
            yield i
            #return
        except MessageType, args:
            pass # do something

print 'And now for something completely different:'
p = powers(2)                   # args binding
print p.next()                  # init, first value
print p.next()                  # second value
print p.next()                  # StopIteration
print p.throw(LastNumber())     # terminate and return i
print p.throw(MessageType(1,2,3))
print p.next()
