# SPA 2008
# Session: "Program Decomposition With Python 2.5 Generators"
# Erik Groeneveld, erik@cq2.nl

from unittest import TestCase, main
from sys import stdout
import random, string
from compose import compose

# This exercise is about creating a stream filter that finds an 'H',
# then concatenates until the next 'B', then concatenates until the
# next 'H', and so on.  This is roughly equivalent to a practical
# problem: finding a header and body in a data stream.

# Below is the complete solution with extracted coroutines, using compose.
# Do the exercise first without compose: inline the readChunk 3 times.

def readChunk(sep):
    chunk = ''
    nextChar = yield
    while nextChar != sep:
        chunk += nextChar
        nextChar = yield
    raise StopIteration(chunk)

def findSubStringStartingWithHandB(next):
    next.send(None) # Initialize generator
    yield readChunk('h') # Disregard characters until first 'h'
    while True:
        header = yield readChunk('b')
        next.send(header)
        body = yield readChunk('h')
        next.send(body)


def basket(aList):
    while True:
        aList.append((yield))

class ComposeTest(TestCase):

    def testOne(self):
        def source():
            while True:
                letter = random.choice(string.ascii_letters.lower())
                if letter in ['h', 'b']:
                    stdout.write(letter.upper()+' ')
                else:
                    stdout.write(letter)
                yield letter

        results = []
        print '\nProcessing:'
        pipeline = compose(findSubStringStartingWithHandB(basket(results)))
        pipeline.next()

        data = source()
        for i in xrange(100):
            pipeline.send(data.next())
        print '\nResults:'
        for line in results:
            stdout.write(line+' ')
        print
main()

