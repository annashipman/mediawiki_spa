from random import choice
from string import ascii_letters
from sys import stdout

def randomchars():
    while True:
        letter = choice(ascii_letters.lower())
        yield letter

def autostart(generator):
    def helper(*args, **kwargs):
        g = generator(*args, **kwargs)
        g.next()
        return g
    return helper

@autostart
def collector(result):
    while True:
        result.append((yield))

def feed(data, generator):
    for item in data:
        generator.send(item)