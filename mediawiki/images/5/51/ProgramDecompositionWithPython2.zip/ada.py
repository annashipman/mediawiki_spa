from util import autostart
from functools import partial as curry

class RendezVousError(Exception):
    pass

class entry(Exception): # Superclass for entry declaration
    def __iter__(self):
        return iter(self.args[0]) # make such tuple unpacking for the arguments works properly


class Dispatch(object):

    def __init__(self, generator):
        self._generator = generator

    def __getattr__(self, name):
        itsLocals = self._generator.gi_frame.f_locals
        if name in itsLocals:
            itsLocal = itsLocals[name]
            if issubclass(itsLocal, entry):
                return curry(self._call, itsLocal)
        return getattr(self._generator, name)

    def _call(self, entryClass, *args):
        try:
            return self._generator.throw(entryClass(args))
        except entryClass:
            raise RendezVousError("Not ready for rendez-vous on '" + entryClass.__name__ + "'")

def dispatch(generator):
    @autostart
    def helper(*args, **kwargs):
        return Dispatch(generator(*args, **kwargs))
    return helper