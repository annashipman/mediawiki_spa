# SPA 2008
# Session: "Program Decomposition With Python 2.5 Generators"
# Erik Groeneveld, erik@cq2.nl



###########################################
#Exercise 1: create a generator that represents all powers of n
def powersOf(n):
    i = 1
    while True:
        yield i**n
        i = i + 1
p = powersOf(3)
###########################################
