from util import collector, randomchars, autostart
from sys import stdout
from types import GeneratorType


# Exercise 2 -step 2
# Extract duplicate code.  If we would have fucntions:
#   fragment = readUntil('b')
# With generators, Guido and others suggested:
#   fragment = yield readUntil('b')
#
# Create a generator 'compose' that makes this possible.
# To 'return' a value use: raise StopIteration(value)

def testit():
    print '\nProcessing:'
    results = []
    pipeline = compose(findSubStringStartingWithHandB(collector(results)))
    for i, letter in zip(xrange(100), randomchars()):
        if letter in ['h', 'b']:
            stdout.write('>')
        stdout.write(letter)
        pipeline.send(letter)
    print '\nResults:'
    for line in results:
        stdout.write(line+' ')
    print


def findSubstring(terminator):
    substring = ''
    char = yield
    while char != terminator:
        substring += char
        char = yield
    raise StopIteration(substring)

def findSubStringStartingWithHandB(next):
    yield findSubstring('h')
    while True:
        substring = yield findSubstring('b')
        next.send(substring)
        substring = yield findSubstring('h')
        next.send(substring)

@autostart
def compose(aGenerator):
    message = None
    while True:
        response = aGenerator.send(message)
        if type(response) == GeneratorType:
            generator = response
            message = None
            while True:
                try:
                    response = generator.send(message)
                    message = yield response
                except StopIteration, e:
                    message = e.args[0]
                    break
        else:
            message = yield response

testit()