#Intro into Pipelines
from util import collector

def flattenPipe(nextPipe):
    while True:
        aString = yield
        for char in aString:
            nextPipe.send(char)

result = []
flatter = flattenPipe(collector(result))
flatter.next()
flatter.send('John')
flatter.send('Pete')
assert result == ['J', 'o', 'h', 'n', 'P', 'e', 't', 'e']

from util import autostart

@autostart
def table(cols, next):
    while True:
        row = []
        for n in range(cols):
            char = yield
            row.append(char)
        next.send(row)

result = []
t = table(3, collector(result))
for char in ['J', 'o', 'h', 'n', 'P', 'e', 't', 'e']:
    t.send(char)
print result

from util import feed

@autostart
def table(cols, next):
    while True:
        row = []
        try:
            for n in range(cols):
                char = yield
                row.append(char)
        except GeneratorExit:
            next.send(row)
            return
        next.send(row)

result = []
t = table(3, collector(result))
feed(['J', 'o', 'h', 'n', 'P', 'e', 't', 'e'], t)
t.close()
assert result == [['J', 'o', 'h'], ['n', 'P', 'e'], ['t', 'e']], result


# Intermediate Exercise: Combine
# Jackson: there is a boundary clash he
re
# Take 1
result = []
t = table(3, collector(result))
table2 = flattenPipe(t)
table2.next()
table2.send('John')
table2.send('Pete')
table2.close()                  # Why does it not work?
print result

# Take 2
def table2(cols, next):
    t = table(cols, next)
    f = flattenPipe(t)
    f.next()
    return f

result = []
t = table2(3, collector(result))
t.send('John')
t.send('Pete')
t.close()                       # Why does it work?
assert result == [['J', 'o', 'h'], ['n', 'P', 'e'], ['t', 'e']], result
