from ltqnorm import ltqnorm

for i in range(1, 100):
    probability = float(i) / 100.0
    print str(probability) + "," + str(ltqnorm(probability))
