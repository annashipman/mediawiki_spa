// spa_example.cpp : Defines the entry point for the console application.
//

#include <math.h>
#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

double CumulativeNormal(const double x)
{
  const double b1 =  0.319381530;
  const double b2 = -0.356563782;
  const double b3 =  1.781477937;
  const double b4 = -1.821255978;
  const double b5 =  1.330274429;
  const double p  =  0.2316419;
  const double c  =  0.39894228;

  if(x >= 0.0) {
      double t = 1.0 / ( 1.0 + p * x );
      return (1.0 - c * exp( -x * x / 2.0 ) * t *
      ( t *( t * ( t * ( t * b5 + b4 ) + b3 ) + b2 ) + b1 ));
  }
  else {
      double t = 1.0 / ( 1.0 - p * x );
      return ( c * exp( -x * x / 2.0 ) * t *
      ( t *( t * ( t * ( t * b5 + b4 ) + b3 ) + b2 ) + b1 ));
    }
}

/*
 * Lower tail quantile for standard normal distribution function.
 *
 * This function returns an approximation of the inverse cumulative
 * standard normal distribution function.  I.e., given P, it returns
 * an approximation to the X satisfying P = Pr{Z <= X} where Z is a
 * random variable from the standard normal distribution.
 *
 * The algorithm uses a minimax approximation by rational functions
 * and the result has a relative error whose absolute value is less
 * than 1.15e-9.
 *
 * Author:      Peter J. Acklam
 * Time-stamp:  2002-06-09 18:45:44 +0200
 * E-mail:      jacklam@math.uio.no
 * WWW URL:     http://www.math.uio.no/~jacklam
 *
 * C implementation adapted from Peter's Perl version
 */

#include <math.h>
#include <errno.h>

/* Coefficients in rational approximations. */
static const double a[] =
{
	-3.969683028665376e+01,
	 2.209460984245205e+02,
	-2.759285104469687e+02,
	 1.383577518672690e+02,
	-3.066479806614716e+01,
	 2.506628277459239e+00
};

static const double b[] =
{
	-5.447609879822406e+01,
	 1.615858368580409e+02,
	-1.556989798598866e+02,
	 6.680131188771972e+01,
	-1.328068155288572e+01
};

static const double c[] =
{
	-7.784894002430293e-03,
	-3.223964580411365e-01,
	-2.400758277161838e+00,
	-2.549732539343734e+00,
	 4.374664141464968e+00,
	 2.938163982698783e+00
};

static const double d[] =
{
	7.784695709041462e-03,
	3.224671290700398e-01,
	2.445134137142996e+00,
	3.754408661907416e+00
};

#define LOW 0.02425
#define HIGH 0.97575

double InverseNormal(double p)
{
	double q, r;

	errno = 0;

	if (p < 0 || p > 1)
	{
		errno = EDOM;
		return 0.0;
	}
	else if (p == 0)
	{
		errno = ERANGE;
		return -HUGE_VAL /* minus "infinity" */;
	}
	else if (p == 1)
	{
		errno = ERANGE;
		return HUGE_VAL /* "infinity" */;
	}
	else if (p < LOW)
	{
		/* Rational approximation for lower region */
		q = sqrt(-2*log(p));
		return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
			((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
	}
	else if (p > HIGH)
	{
		/* Rational approximation for upper region */
		q  = sqrt(-2*log(1-p));
		return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
			((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
	}
	else
	{
		/* Rational approximation for central region */
    		q = p - 0.5;
    		r = q*q;
		return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q /
			(((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1);
	}
}

double RandomNormal()
{
	double dUniform = rand() * 1.0 / RAND_MAX;
	double dNormal = InverseNormal(dUniform);

	return dNormal;
}

//
// MonteCarloLossDistn
//

std::vector<double> MonteCarloLossDist(
	double dProb,
	double dCorr,
	long lNumNames,
	long lNumSimulations)
{
	std::vector<double> vLossDist(lNumNames+1); // 0 -> lNumNames

	double dAlpha = InverseNormal(dProb);
	double dSqrtCorr = sqrt(1.0 - dCorr * dCorr);

	for(long lSimulation = 0; lSimulation < lNumSimulations; ++lSimulation)
	{
		long lNumDefaults = 0;
		// generate market factor
		double dMkt = RandomNormal();

		// determine number of names in default
		for (long lName = 0; lName < lNumNames; ++lName)
		{
			double dIdio = RandomNormal();
			// mix the variables
			double dA = dCorr * dMkt + dSqrtCorr * dIdio;
			// and determine if this name is in default
			if (dA < dAlpha) 
				++lNumDefaults;
		}

		// assume loss = number of names in default i.e. ignore any recovery possibility etc.
		++vLossDist[lNumDefaults];
	}

	// finally, normalise the loss distribution
	for (long lName = 0; lName <= lNumNames; ++lName)
		vLossDist[lName] /= lNumSimulations;

	return vLossDist;
}	

vector<double> SemiAnalyticLossDist(
	double dProb,
	double dCorr,
	long lNumNames)
{
	vector<double> vLossDist(lNumNames+1); // 0 -> lNumNames

	vector<double> vWeight(4);
	vector<double> vZero(4);
    
    // Gauss-Hermite weights & coefficients
    vWeight[0] = 0.804914090005513;
    vWeight[1] = 8.13128354472452e-02;
    vWeight[2] = 0.804914090005513;
    vWeight[3] = 8.13128354472452e-02;
    
    vZero[0] = 0.52464762327529;
    vZero[1] = 1.65068012388578;
    vZero[2] = -0.52464762327529;
    vZero[3] = -1.65068012388578;

	double dAlpha = InverseNormal(dProb);
	double dSqrtCorr = sqrt(1.0 - dCorr * dCorr);

	for (long lNode = 0; lNode < 4; ++lNode)
	{
		// calculate the conditional default probability
		double dMkt = vZero[lNode] * sqrt(2.0);
		double dArg = (dAlpha - dCorr * dMkt) / dSqrtCorr;
		double dCondProb = CumulativeNormal(dArg);

		// first line in intermediate table
		vector<double> vIntermediateLossDist(lNumNames+1, 0.0);
		vIntermediateLossDist[0] = 1.0;
		
		// subsequent lines in the intermediate table
		for (long lLine = 0; lLine < lNumNames; ++lLine)
		{
			for (long lName = lNumNames; lName > 0; --lName)
				vIntermediateLossDist[lName] = 
						vIntermediateLossDist[lName] * (1.0 - dCondProb) +
						vIntermediateLossDist[lName-1] * dCondProb;

			// leftmost point of table has diff calc
			vIntermediateLossDist[0] = vIntermediateLossDist[0] * (1.0 - dCondProb);
		}

		// add to overall dist
		for (long lName = 0; lName <= lNumNames; ++lName)
			vLossDist[lName] += vWeight[lNode] * vIntermediateLossDist[lName] / sqrt(3.141592654);
	}

	return vLossDist;
}

//
// 'test bed'
//

int main(int argc, char* argv[])
{
	cout << "Some inverse normals ... " << endl;
	cout << setprecision(10) << endl;

	cout << " 0.5 -> " << InverseNormal(0.5) << endl;
	cout << " 0.2 -> " << InverseNormal(0.2) << endl;
	cout << " 0.8 -> " << InverseNormal(0.8) << endl;
	cout << " 0.975 -> " << InverseNormal(0.975) << endl;
	cout << " 0.025 -> " << InverseNormal(0.025) << endl;
	cout << endl;

	// Loss distribution calculations
	double dProb = 0.1;
	double dCorr = 0.6;
	long lNumNames = 10;

	cout << "Monte carlo example ... " << endl;
	long lNumSimulations = 500000;
	vector<double> vLossDist = MonteCarloLossDist(dProb, dCorr, lNumNames, lNumSimulations);
	
	for (long lName = 0; lName <= lNumNames; ++lName)
		cout << "[" << lName << "] " << vLossDist[lName] << endl;
	
	cout << endl << "Semi-analytic example ... " << endl;
	vLossDist = SemiAnalyticLossDist(dProb, dCorr, lNumNames);

	for (long lName = 0; lName <= lNumNames; ++lName)
		cout << "[" << lName << "] " << vLossDist[lName] << endl;

	return 0;
}

