let assert_float = fun expected actual ->
	OUnit.assert_equal  ~cmp:OUnit.cmp_float ~printer:(fun f -> string_of_float f) expected actual
	
