let times_do = fun count f -> for i = 1 to count do f i done


let monte_carlo = fun probability correlation num_names num_simulations ->
	let alpha = NormalDistributions.inverse probability in
	let sqrt_corr = sqrt( 1.0 -. (correlation *. correlation)) in
	let is_in_default_for = fun market_factor -> 
		alpha > (correlation *. market_factor +. sqrt_corr *. (NormalDistributions.random())) in
		
  let additional_default_for = fun market_factor ->
		if is_in_default_for market_factor then 1 else 0 in
		 
	let num_defaults = fun market_factor -> 
		let rec count_defaults i =
			if i = 0 then 0 else (additional_default_for market_factor) + count_defaults (i - 1) in
		count_defaults num_names
	in 
	
	let loss_distribution = Array.make (num_names + 1) 0.0 in
	times_do num_simulations 
		(fun _ ->
			let defaults = (num_defaults (NormalDistributions.random())) in
		  loss_distribution.(defaults) <- loss_distribution.(defaults) +. 1.0);
  Array.map (fun loss -> loss /. float_of_int(num_simulations)) loss_distribution
