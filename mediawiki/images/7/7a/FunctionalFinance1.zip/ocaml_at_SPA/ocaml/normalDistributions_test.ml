open OUnit
open TestExtras

let test_rejects_negative_probabilities _ =
  assert_raises (NormalDistributions.OutOfBounds "Probability 1.000000") (fun _ -> NormalDistributions.inverse 1.0)

let test_generates_same_results_as_test_values _ =
	  let values = open_in "test_values/inverse_normal_values.csv" in
		let assert_inverse_normal probability expected =
			assert_float expected (NormalDistributions.inverse probability) in
		let rec assert_each () =
			Scanf.sscanf (input_line values) "%f , %f" assert_inverse_normal;
			assert_each ()
		in
			try assert_each() with End_of_file -> close_in values
		;;
	
let suite = "Normal Distributions" >::: [
  "rejects negative probabilityies" >:: test_rejects_negative_probabilities;
	"generates same results as test values" >:: test_generates_same_results_as_test_values ]


let _  =
	run_test_tt_main suite;; 