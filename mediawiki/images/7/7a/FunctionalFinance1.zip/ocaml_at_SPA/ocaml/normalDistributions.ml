(* see http://home.online.no/~pjacklam/notes/invnorm *)
open List;;

exception OutOfBounds of string;;

let  a = [-3.969683028665376e+01; 
           2.209460984245205e+02; 
          -2.759285104469687e+02; 
           1.383577518672690e+02; 
          -3.066479806614716e+01;
           2.506628277459239e+00 ]
let b = [-5.447609879822406e+01;
          1.615858368580409e+02;
         -1.556989798598866e+02;
          6.680131188771972e+01;
         -1.328068155288572e+01; 
				  1.0 ]
let c = [-7.784894002430293e-03;
         -3.223964580411365e-01;
         -2.400758277161838e+00;
         -2.549732539343734e+00;
          4.374664141464968e+00;
          2.938163982698783e+00 ]
let d = [7.784695709041462e-03;
         3.224671290700398e-01;
         2.445134137142996e+00;
         3.754408661907416e+00;
         1.0 ]
let low_prob = 0.02425
let high_prob = 1.0 -. low_prob

let inverse = fun probability ->
  let accumulate = fun coeffs multiplier ->  
    fold_left (fun last_val this_val -> (last_val *. multiplier) +. this_val) 0.0 coeffs in
  let outer_approx = fun adjusted_prob -> 
    let multiplier = sqrt (-2.0 *. log(adjusted_prob)) in
	  (accumulate c multiplier) /. (accumulate d multiplier)
  in 
    match probability with
      p when p <= 0.0 || 1.0 <= p ->
        raise (OutOfBounds (Format.sprintf "Probability %f" probability))
   | p when (0.0 < p) && (p < low_prob) -> outer_approx probability
   | p when (high_prob < p) && (p < 1.0) -> -. (outer_approx (1.0 -. probability))
   | _ ->  let q = probability -. 0.5 in
	         let r = q *. q in
					   ((accumulate a r) *. q) /. (accumulate b r)
	 ;;

let random = fun _ ->
	inverse (Random.float 1.0)
