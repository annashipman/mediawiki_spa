open OUnit
open TestExtras

let test_monte_carlo_loss_distribution _ =
		let expecteds = [0.533306; 0.220882; 0.11124; 0.060754; 0.03414; 0.01937; 0.010672; 0.005538; 0.00262; 0.00114; 0.000338] in
		let actuals = LossDistributions.monte_carlo 0.1 0.6 10 50000 in
			(* Array.iter (fun loss -> Printf.printf "%f, " loss) actuals; Printf.printf "\n"; *) 
		  List.iter2 assert_float expecteds (Array.to_list actuals) 
		;;
	
let suite = "Loss Distributions" >::: [
  "Monte Carlo Loss Distribution" >:: test_monte_carlo_loss_distribution ]

let _  = 
	run_test_tt_main suite;;
