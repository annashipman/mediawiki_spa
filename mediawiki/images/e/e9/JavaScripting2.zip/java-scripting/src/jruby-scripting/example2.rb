include_class "java.io.File"
include_class "com.example.domain.Utility"

files = File.new("/")
files.listFiles.each do |item|
	if item.isFile
		Utility.new.run(item, true)
	end
end
