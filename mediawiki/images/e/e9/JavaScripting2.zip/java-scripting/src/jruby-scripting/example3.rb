include_class "com.example.domain.Utility"
include_class "com.example.domain.SpecialDomainFileFinder"

fileFinder = SpecialDomainFileFinder.new
files = fileFinder.find
files.each do |item| 
    Utility.new.run(item, true)
end
