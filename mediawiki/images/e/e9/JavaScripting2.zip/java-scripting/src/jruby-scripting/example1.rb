include_class "java.io.File"
include_class "com.example.domain.Utility"

file = File.new("fred.txt")

utility = Utility.new
utility.run(file, true)
