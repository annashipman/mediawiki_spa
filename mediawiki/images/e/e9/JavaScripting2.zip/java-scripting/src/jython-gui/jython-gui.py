from java.io import *
from java.awt import *
from javax.swing import *
from com.example.domain import Utility

def run(event):
    selection = fileChooser.selectedFile
    if selection:
        Utility().run(selection, checkBox.selected)

def browse(event):
    fileChooser.showOpenDialog(frame)
    
frame = JFrame("Utility")
frame.defaultCloseOperation = JFrame.EXIT_ON_CLOSE

fileChooser = JFileChooser()

runButton = JButton("Run", actionPerformed = run)
frame.contentPane.add(runButton, BorderLayout.SOUTH)

browseButton = JButton("Browse", actionPerformed = browse)
frame.contentPane.add(browseButton, BorderLayout.NORTH)

checkBox = JCheckBox("Overwrite")
frame.contentPane.add(checkBox, BorderLayout.CENTER)

frame.pack()
frame.show()