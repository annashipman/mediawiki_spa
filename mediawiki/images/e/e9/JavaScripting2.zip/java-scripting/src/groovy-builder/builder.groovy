import groovy.xml.*
import java.io.*

class Person {
    @Property firstName
    @Property lastName
    @Property dob
    @Property friends
}

jim = new Person(firstName: "Jim", lastName: "Smith", dob: "27/09/1967")
jim.friends = [ 
	new Person(firstName: "Bob", lastName: "Duggan"),
 	new Person(firstName: "Alan", lastName: "Nutley") ]

writer = new StringWriter()	 	
buildPerson(jim, new MarkupBuilder(writer))
println writer.toString()

def buildPerson(person, builder) {
	builder.person() {
		name(surname:person.lastName, 'christian-name':person.firstName)
		birthday(person.dob)	
	   	friends() {
	   		person.friends.each(
	   			{ |item| friend("${item.lastName}, ${item.firstName}") })
	   	}
	}
}


