package com.example.scriptSupport;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.apache.bsf.BSFException;
import org.apache.bsf.BSFManager;
import org.apache.commons.io.FileUtils;

public class ScriptRunner {

	private BSFManager scriptManager = new BSFManager();
	
	public ScriptRunner() {
		BSFManager.registerScriptingEngine(
		    "beanshell", 
		    bsh.util.BeanShellBSFEngine.class.getName(), 
		    new String[] {"java" });
		
		BSFManager.registerScriptingEngine(
			"groovy", 
			org.codehaus.groovy.bsf.GroovyEngine.class.getName(), 
			new String[] { "groovy", "gy" });
	}
		
	public void run(File sourceFile) throws BSFException, IOException {
		run(sourceFile, BSFManager.getLangFromFilename(sourceFile.getName()));
	}
	
	public void run(File sourceFile, String language) throws BSFException, IOException {
		scriptManager.exec(language,
				sourceFile.toString(), 1, 1, readFile(sourceFile));
	}
	
	public void runLines(File sourceFile, String language) throws IOException {
		List<String> lines = readLines(sourceFile);
		for (int i = 0; i < lines.size(); i++) {
			try {
				scriptManager.exec(language,
					sourceFile.toString(), i + 1, 1, lines.get(i));
			} catch (BSFException x) {
				throw new RuntimeException("Exception running script at line " + i, x);
			}
		}
	}	
	public void register(String name, Object value) throws BSFException {
		scriptManager.declareBean(name, value, value.getClass());
	}

	public Object get(String name) {
		return scriptManager.lookupBean(name);
	}

	@SuppressWarnings("unchecked")
	private List<String> readLines(File file) throws IOException {
		return FileUtils.readLines(file, Charset.defaultCharset().name());
	}
	
	private String readFile(File file) throws IOException {
		return FileUtils.readFileToString(file, Charset.defaultCharset().name());
	}
	
	public static void main(String[] args) throws BSFException, IOException {
		new ScriptRunner().run(new File(args[0]));
	}

}
