package com.example.beanshell;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;

import org.apache.bsf.BSFException;
import org.apache.bsf.BSFManager;
import org.apache.commons.io.FileUtils;

public class Main {
	
	private static final File FILE = new File("src/java/com/example/beanshell/test.java");

	public void run() {
		JFrame f = new JFrame("Run code");
		f.getContentPane().add(new JButton(new AbstractAction("Run"){
			public void actionPerformed(ActionEvent e) {
				onAction();
			}
		}));

		f.pack();
		f.setVisible(true);		
	}

	private void onAction() {
		try {
			BSFManager scriptManager = new BSFManager();
			
			Object input = "World";
			scriptManager.declareBean("input", input, input.getClass());
			
			Object result = scriptManager.eval("beanshell", 
					"script name", 1, 1, 
					readFile(FILE));
			
			System.out.println(String.format("Output = %s", result));
		} catch (Exception x) {
			throw new RuntimeException(x);
		}
	}
	
	private static String readFile(File file) throws IOException {
		return FileUtils.readFileToString(file, Charset.defaultCharset().name());
	}

	public static void main(String[] args) throws BSFException {
		new Main().run();
	}
		

}
