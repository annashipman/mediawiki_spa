package com.example.domain;

import java.io.File;

public class SpecialDomainFileFinder {

	public File[] find() {
		return new File[] {
			new File("file1.txt"), 
			new File("file2.txt")};
	}

}
