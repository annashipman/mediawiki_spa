package com.example.domain;

import java.io.File;

public class Utility {

	public void run(File dir, boolean overwrite) {
		System.out.println(String.format("File : %s, overwrite = %s", dir, overwrite));
	}
	
	public static void main(String[] args) {
		File file = new File(args[0]);
		boolean overwrite = args.length == 2 ? args[1].equals("true") : false;
		new Utility().run(file, overwrite);
	}
	
}
