package ioc.testing;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TextFileWriter {
	private File file_ ;
	
	public TextFileWriter(String filename) {
		this.file_ = new File(filename) ;
	}
	
	public void writeToFile(String content) throws IOException {
		FileWriter fw = new FileWriter(this.file_) ;
		fw.write(content) ;
		fw.close() ;
	}
}
