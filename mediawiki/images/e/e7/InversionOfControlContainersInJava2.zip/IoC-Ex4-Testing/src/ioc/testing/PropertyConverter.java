package ioc.testing;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class PropertyConverter {
	
	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Usage: PropertyConverter properties_file xml_file") ;
			System.exit(1) ;
		}
		try {
			String propFile = args[0] ;
			String xmlFile = args[1] ;
 			PropertyConverter pc = new PropertyConverter() ;
			pc.propertyFileToXmlFile(propFile, xmlFile) ;
		} catch(Exception ex) {
			System.err.println("Unexpected exception: " + ex) ;
			ex.printStackTrace() ;
		}
	}

	public void propertyFileToXmlFile(String propFileName, String xmlFileName)
			throws IOException {

		PropertyFileReader propReader = new PropertyFileReader(propFileName);
		String xmlProperties = propertiesToXML(propReader.getProperties());
		TextFileWriter tfw = new TextFileWriter(xmlFileName);
		tfw.writeToFile(xmlProperties);
	}

	private String propertiesToXML(Properties p) {
		StringBuffer ret = new StringBuffer();

		ret.append("<?xml version='1.0'?>\n");
		ret.append("<properties>\n");
		List orderedKeys = new ArrayList(p.keySet());
		Collections.sort(orderedKeys);
		Iterator ki = orderedKeys.iterator();
		while (ki.hasNext()) {
			String key = (String) ki.next();
			String val = p.getProperty(key);
			ret.append("<property name='" + key + "'>" + val + "</property>\n");
		}
		ret.append("</properties>\n");

		return ret.toString();
	}

}
