package org.spaconference;

import com.objectsbydesign.calc.model.Cpu;
import com.objectsbydesign.calc.view.Calculator;
import com.objectsbydesign.calc.view.CalculatorFrame;
import com.objectsbydesign.calc.view.CalculatorTape;

public class CalculatorMain
{
	public static void main(String[] args) {
        CalculatorTape tape = new CalculatorTape();
        
        Cpu cpu = new Cpu();
        cpu.addObserver(tape) ;
        
        Calculator calc = new Calculator(cpu) ;
        
        CalculatorFrame frame = new CalculatorFrame(calc);
	}
}
