package com.objectsbydesign.calc.model;

import java.util.Observer;

public interface ICpu {
    /**
     * Enter operations into the CPU
     */
    public void enterOperation(String opcode);

    /**
     * Enter numbers into the CPU. The CPU uses its current state
     * to determine what to do with the number.
     */
    public void enterDigit(String digit);

    /**
     * Push the display input onto the operand stack, and broadcasts the
     * input to all observers
     */
    public void pushDisplayRegister();

    /**
     * Push the operand value onto the operand stack.
     */
    public void loadOperand(Value value);

    /**
     * Push the operation onto the operation stack or execute immediately, and broadcast the
     * input to all observers
     */
    public void pushOperation(Operation op);
    
    /**
     *  Execute the operation and broadcast the input to all observers
     */
    public void executeOperation(Operation op);

    /**
     *  Replace the top operation on the operation stack.
     */
    public void replaceOperation(Operation op);

    /**
     * Execute the equals function.
     */
    public void equals();

    /**
     * Set the display register with any calculated results
     */
    public void updateDisplay();

    /**
     * Executes the clear function. Empties the stacks and clears the display register.
     */
    public void clear();

    /**
     * Resets the CPU. Empties the stacks and resets the display register.
     */
    public void reset();

    public void addDisplayObserver(Observer observer);
    
    public void addMemoryObserver(Observer observer);

    public void setUpdateDisplay();

    public OperandStack getOperandStack();

    public OperationStack getOperationStack();

    public Memory getMemoryRegister();

    public Display getDisplayRegister();

	/**
	 * @return Returns the enteringNumberState.
	 */
	public State getEnteringNumberState();

	/**
	 * @return Returns the waitingForInputState.
	 */
	public State getWaitingForInputState();

	/**
	 * @return Returns the waitingForNumberState.
	 */
	public State getWaitingForNumberState();

	/**
	 * @return Returns the waitingForOperationState.
	 */
	public State getWaitingForOperationState();

}
