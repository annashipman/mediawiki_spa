package org.spaconference;

import java.util.Observable;

import com.objectsbydesign.calc.model.Cpu;
import com.objectsbydesign.calc.model.ICpu;
import com.objectsbydesign.calc.view.Calculator;
import com.objectsbydesign.calc.view.CalculatorFrame;
import com.objectsbydesign.calc.view.CalculatorTape;

public class CalculatorMain
{
	public static void main(String[] args) {
        CalculatorTape tape = new CalculatorTape();
        
        ICpu cpu = new Cpu();
        
        /*
         * This line illustrates an issue with the com.objectsbydesign.calc.model.ICpu 
         * interface that has been introduced to allow for using a mock cpu instead of
         * the fully implemented cpu.
         * 
         * As the interface does not declare methods implemented by the java.util.Observable
         * class, we are facing a rather clumsy cast in order to register the tape as an 
         * observer of the cpu. Having said that, would it not be nice of Observable was an
         * interface rather than a plain class? This would allow for a very neat solution of
         * the problem.
         * 
         * What other solution can you think of to avoid the cast?
         */
        ((Observable)cpu).addObserver(tape);
        
        Calculator calc = new Calculator(cpu);
        
        CalculatorFrame frame = new CalculatorFrame(calc);
	}
}