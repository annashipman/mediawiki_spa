package org.spaconference;

import java.util.Observable;

import com.objectsbydesign.calc.model.CpuMock;
import com.objectsbydesign.calc.model.ICpu;
import com.objectsbydesign.calc.view.Calculator;
import com.objectsbydesign.calc.view.CalculatorFrame;
import com.objectsbydesign.calc.view.CalculatorTape;

public class CalculatorMockMain
{
	public static void main(String[] args) {
        CalculatorTape tape = new CalculatorTape();
        
        ICpu cpu = new CpuMock();

        /*
         * When using the mock as provided in this solution, the tape tends to fall over.
         * 
         * Why is that the case and how could this issue be solved?
         */
        //((Observable)cpu).addObserver(tape);
        
        Calculator calc = new Calculator(cpu);
        
        CalculatorFrame frame = new CalculatorFrame(calc);
	}
}
