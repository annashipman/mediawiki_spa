/**
    Object-Oriented Calculator

    Copyright (C) 1999-2002, Objects by Design, Inc. All Rights Reserved.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation. A copy of the license may be found at
    http://www.objectsbydesign.com/projects/gpl.txt
 */

package com.objectsbydesign.calc.view;

import java.util.Observer;
import java.util.logging.Logger;

import com.objectsbydesign.calc.model.ICpu;

public class Calculator {

    // Executes the operations
    ICpu cpu;

    private static Logger logger = Logger.getAnonymousLogger();
    
    /**
     * Default constructor is provided to allow setter based dependency injection.
     */
    public Calculator() {
    	logger.info("executing Calculator()");
    }

    public Calculator(ICpu cpu) {
    	logger.info("executing Calculator(Cpu cpu)");
        this.cpu = cpu;
    }

    public void enterOperation(String operation) {

        // input the operation to the CPU
        cpu.enterOperation(operation);
    }

    public void enterDigit(String digit) {

        // input the number to the CPU
        cpu.enterDigit(digit);
    }

    public void addDisplayObserver(Observer observer) {
        cpu.addDisplayObserver(observer);
    }

    public void addMemoryObserver(Observer observer) {
        cpu.addMemoryObserver(observer);
    }

	/**
	 * @return Returns the cpu.
	 */
	public ICpu getCpu() {
		return cpu;
	}

	/**
	 * @param cpu The cpu to set.
	 */
	public void setCpu(ICpu cpu) {
    	logger.info("executing setCpu(Cpu cpu)");
		this.cpu = cpu;
	}

}


