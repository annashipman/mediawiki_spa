package ioc.setterinj;

public interface Adder {
	
	public int add(int x, int y) ;

}
