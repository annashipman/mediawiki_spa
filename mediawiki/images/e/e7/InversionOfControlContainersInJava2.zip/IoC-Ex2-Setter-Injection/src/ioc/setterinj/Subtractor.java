package ioc.setterinj;

public interface Subtractor {

	public int subtract(int x, int y) ;
}
