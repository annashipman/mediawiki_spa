package ioc.ctorinj;

public class SetterApplication {

	Adder adder_ ;
	Subtractor subtractor_ ;
	String startMsg_ ;
	String endMsg_ ;
	
	public SetterApplication(Adder adder, Subtractor subtractor, 
			                String startMsg, String endMsg) {
		this.adder_ = adder ;
		this.subtractor_ = subtractor ;
		this.startMsg_ = startMsg ;
		this.endMsg_ = endMsg ;
	}
	
	public void performSums(int x, int y) {
		System.out.println(this.startMsg_) ;
		
		System.out.println("Adding " + x + " and " + y + " = " +
				this.adder_.add(x,y)) ;

		System.out.println("Subtracting " + x + " and " + y + " = " +
				this.subtractor_.subtract(x,y)) ;
		
		System.out.println(this.endMsg_) ;
	}	
}
