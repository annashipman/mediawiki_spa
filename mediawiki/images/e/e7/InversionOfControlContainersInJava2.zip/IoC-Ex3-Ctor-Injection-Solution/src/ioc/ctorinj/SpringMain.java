package ioc.ctorinj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringMain {

	static final String APPLICATION_CFG_FILE = "ctorinjection.xml" ;
	
	public static void main(String[] args) {
		ApplicationContext c  = new ClassPathXmlApplicationContext(APPLICATION_CFG_FILE);
		SetterApplication app = (SetterApplication)c.getBean("mainBean") ;
		app.performSums(10, 12) ;
	}
}
