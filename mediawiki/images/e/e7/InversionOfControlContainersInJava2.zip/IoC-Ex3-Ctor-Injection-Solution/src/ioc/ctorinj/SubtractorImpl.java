package ioc.ctorinj;

public class SubtractorImpl implements Subtractor {

	public int subtract(int x, int y) {
		return x-y;
	}

}
