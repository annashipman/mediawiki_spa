package ioc.testing;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyFileReaderImpl implements PropertyFileReader {

	String filename_ ;
	Properties props_ ;
	
	public PropertyFileReaderImpl(String filename) throws IOException {
		this.filename_ = filename ;
		this.props_ = new Properties() ;
		InputStream fis = new FileInputStream(this.filename_) ;
		this.props_.load(fis) ;
	}
	
	public Properties getProperties() {
		return this.props_ ;
	}
	
	public String getProperty(String key) {
		return this.props_.getProperty(key) ;
	}
}
