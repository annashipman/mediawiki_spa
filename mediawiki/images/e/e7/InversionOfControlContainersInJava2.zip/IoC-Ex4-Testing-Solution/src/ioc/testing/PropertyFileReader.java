package ioc.testing;

import java.util.Properties;

public interface PropertyFileReader {

	public abstract Properties getProperties();

	public abstract String getProperty(String key);

}