package ioc.testing;

import java.io.IOException;

public interface TextFileWriter {

	public abstract void writeToFile(String content) throws IOException;

}