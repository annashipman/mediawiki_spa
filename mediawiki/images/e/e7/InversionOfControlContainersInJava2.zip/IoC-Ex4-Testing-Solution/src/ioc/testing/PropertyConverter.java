package ioc.testing;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PropertyConverter {
	
	static final String APPLICATION_CFG_FILE = "unittesting.xml" ;
	
	PropertyFileReader reader_ ;
	TextFileWriter writer_ ;
	
	public static void main(String[] args) {
		try {
			ApplicationContext c  = new ClassPathXmlApplicationContext(APPLICATION_CFG_FILE);
			PropertyConverter app = (PropertyConverter)c.getBean("mainBean") ;
			app.propertyFileToXmlFile() ;
		} catch(Exception ex) {
			System.err.println("Unexpected exception: " + ex) ;
			ex.printStackTrace() ;
		}
	}
	
	public PropertyConverter(PropertyFileReader reader, TextFileWriter writer) {
		this.reader_ = reader ;
		this.writer_ = writer ;
	}

	public void propertyFileToXmlFile()
			throws IOException {

		String xmlProperties = propertiesToXML(this.reader_.getProperties());
		this.writer_.writeToFile(xmlProperties);
	}

	private String propertiesToXML(Properties p) {
		StringBuffer ret = new StringBuffer();

		ret.append("<?xml version='1.0'?>\n");
		ret.append("<properties>\n");
		List orderedKeys = new ArrayList(p.keySet());
		Collections.sort(orderedKeys);
		Iterator ki = orderedKeys.iterator();
		while (ki.hasNext()) {
			String key = (String) ki.next();
			String val = p.getProperty(key);
			ret.append("<property name='" + key + "'>" + val + "</property>\n");
		}
		ret.append("</properties>\n");

		return ret.toString();
	}

}
