package ioc.mocks;

import java.util.Properties;

import ioc.testing.PropertyFileReader;

public class TestingPropertyFileReader implements PropertyFileReader {
	
	Properties testSet_ ;
	
	public TestingPropertyFileReader(Properties testSet) {
		this.testSet_ = testSet ;
	}

	public Properties getProperties() {
		return this.testSet_ ;
	}

	public String getProperty(String key) {
		return this.testSet_.getProperty(key) ;
	}
}
