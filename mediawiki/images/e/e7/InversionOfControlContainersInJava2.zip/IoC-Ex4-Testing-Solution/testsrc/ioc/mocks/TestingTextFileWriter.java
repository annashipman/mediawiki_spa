package ioc.mocks;

import java.io.IOException;
import java.io.StringWriter;

import ioc.testing.TextFileWriter;

public class TestingTextFileWriter implements TextFileWriter {

	StringWriter buffer_ ;
	
	public TestingTextFileWriter() {
		buffer_ = new StringWriter() ;
	}
	
	public void writeToFile(String content) throws IOException {
		buffer_.write(content) ;
	}
	
	public String getWrittenData() {
		return buffer_.toString() ;
	}
}
