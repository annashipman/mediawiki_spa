package ioc.testing;

import ioc.mocks.TestingPropertyFileReader;
import ioc.mocks.TestingTextFileWriter;

import java.io.StringReader;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import junit.framework.TestCase;

public class PropertyConverterTest extends TestCase {

	public void testBasicPropertyFile() throws Exception {
		Properties testProps = new Properties() ;
		testProps.setProperty("property1", "value1") ;
		testProps.setProperty("property2", "value2") ;
		TestingPropertyFileReader reader = new TestingPropertyFileReader(testProps) ;
		
		TestingTextFileWriter writer = new TestingTextFileWriter() ;
		
		PropertyConverter converter = new PropertyConverter(reader, writer);
		converter.propertyFileToXmlFile() ;
		
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder() ;
		Document d = db.parse(new InputSource(new StringReader(writer.getWrittenData()))) ;
		assertNotNull("No document from XML", d) ;
		Node root = d.getChildNodes().item(0) ;
		assertNotNull("No root", root) ;
		assertEquals("Wrong root node", "properties", root.getNodeName()) ;

		List pl = DomUtils.getChildElementsByTagName((Element)root, "property") ;
		assertEquals("Wrong number of properties", 2, pl.size()) ;
		Element prop1 = (Element)pl.get(0) ;
		assertNotNull("No first property", prop1) ;
		assertEquals("Wrong first property name", "property1", prop1.getAttributes().getNamedItem("name").getNodeValue()) ;
		assertEquals("Wrong first property value", "value1", prop1.getChildNodes().item(0).getNodeValue()) ;
		
		Element prop2 = (Element)pl.get(1) ;
		assertNotNull("No second property", prop2) ;
		assertEquals("Wrong second property name", "property2", prop2.getAttributes().getNamedItem("name").getNodeValue()) ;
		assertEquals("Wrong second property value", "value2", prop2.getChildNodes().item(0).getNodeValue()) ;
	}
	
	public void testEmptyPropertyFile() throws Exception {
		Properties testProps = new Properties() ;
		TestingPropertyFileReader reader = new TestingPropertyFileReader(testProps) ;
		
		TestingTextFileWriter writer = new TestingTextFileWriter() ;
		
		PropertyConverter converter = new PropertyConverter(reader, writer);
		converter.propertyFileToXmlFile() ;
		
		DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder() ;
		Document d = db.parse(new InputSource(new StringReader(writer.getWrittenData()))) ;
		assertNotNull("No document from XML", d) ;
		Node root = d.getChildNodes().item(0) ;
		assertNotNull("No root", root) ;
		assertEquals("Wrong root node", "properties", root.getNodeName()) ;
		List pl = DomUtils.getChildElementsByTagName((Element)root, "property") ;
		assertEquals("Unexpected properties", 0, pl.size());
	}
}
