package ioc.ctorinj;

public class SetterApplication {

	Adder adder_ ;
	Subtractor subtractor_ ;
	
	public void performSums(int x, int y) {
		System.out.println("Adding " + x + " and " + y + " = " +
				this.adder_.add(x,y)) ;

		System.out.println("Subtracting " + x + " and " + y + " = " +
				this.subtractor_.subtract(x,y)) ;
	}	
}
