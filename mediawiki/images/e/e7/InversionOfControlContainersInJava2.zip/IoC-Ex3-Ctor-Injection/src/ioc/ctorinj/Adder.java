package ioc.ctorinj;

public interface Adder {
	
	public int add(int x, int y) ;

}
