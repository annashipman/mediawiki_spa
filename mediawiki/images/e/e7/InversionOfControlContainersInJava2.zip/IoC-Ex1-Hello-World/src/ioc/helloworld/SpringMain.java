package ioc.helloworld;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringMain {

	static final String APPLICATION_CFG_FILE = "helloworld.xml" ;
	
	public static void main(String[] args) {
		ApplicationContext c  = new ClassPathXmlApplicationContext(APPLICATION_CFG_FILE);
		SimpleBean b = (SimpleBean)c.getBean("mainBean") ;
		b.useTheStore() ;
	}
}
