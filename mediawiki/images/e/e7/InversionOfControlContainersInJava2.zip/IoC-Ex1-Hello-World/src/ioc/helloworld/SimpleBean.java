package ioc.helloworld;

import org.springframework.beans.factory.InitializingBean;

public class SimpleBean implements InitializingBean {
	
	ObjectStore theStore ;
	
	public void setStore(ObjectStore store) {
		this.theStore = store ;
	}
	
	public void useTheStore() {		
		this.theStore.save(1, "One") ;
		this.theStore.save(2, "Two") ;
		this.theStore.save(3, "Three") ;
		
		System.out.println("Hello - there are " +
				this.theStore.size() + " entries in the store") ;
	}

	public void afterPropertiesSet() throws Exception {
		if (this.theStore == null) {
			throw new IllegalStateException("Object store has not been set") ;
		}
	}

}
