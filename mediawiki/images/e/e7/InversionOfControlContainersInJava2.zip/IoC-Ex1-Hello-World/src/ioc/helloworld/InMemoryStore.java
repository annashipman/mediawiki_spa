package ioc.helloworld;

import java.util.Properties;

public class InMemoryStore implements ObjectStore {

	Properties store = new Properties() ;
	
	public void save(int id, Object obj) {
		this.store.put(new Integer(id), obj) ;
	}

	public Object retrieve(int id) {
		Object ret = null ;
		
		ret = this.store.get(new Integer(id)) ;
		return ret;
	}
	
	public int size() {
		return this.store.size() ;
	}

}
