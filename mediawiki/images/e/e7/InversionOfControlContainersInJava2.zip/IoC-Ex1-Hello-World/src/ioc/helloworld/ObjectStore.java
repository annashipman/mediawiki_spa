package ioc.helloworld;

public interface ObjectStore {
	public void save(int id, Object obj) ;
	public Object retrieve(int id) ;
	public int size() ;
}
