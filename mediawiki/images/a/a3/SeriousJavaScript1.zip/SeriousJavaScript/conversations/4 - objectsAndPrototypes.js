//--------------------------------------------------------------
// ObjectsAndPrototypes
//(c) 2006 Harvey and Marks. All rights reserved.
//--------------------------------------------------------------

//---------------------------------- 1
// OK - this is where things get slightly ... unexpected
// We've seen how to add data and methods to object instances.
// But so far we've not seen anything that corresponds to a class.
// The nearest we have is the Function that acts as an object's constructor.

function Point(x,y) { this.x = x; this.y = y; }
p = new Point(100,200);

// Function objects have a prototype property, which is an object
print(Point.prototype);

// In any object created by a function, a __proto__ property points back to the constructing function's prototype
// NB this is a visible detail of Mozilla's JavaScript implementation - not part of the ECMA standard
print(p.__proto__);
print(p.constructor.prototype);

// They really are the same object for all instances created by the function
print(p.__proto__ === Point.prototype);
q = new Point(10,20);
print(q.__proto === Point.prototype);

// And different per-constructor
print(p.__proto__ === Object.prototype);

// Object field lookup looks at the instance, then the prototype
// So to add a method to all instances, add it to the prototype
Point.prototype.toString = function () { return "Point(" + this.x + "," + this.y + ")"; }
print(p.toString());
print(q.toString());

// (In fact, toString() is called whenever an object needs to be turned into a string representation)
print (p + " " + q);

quit();

//---------------------------------- 2
// The JavaScript idiom for defining a class

function Point1(x,y) { this.x = x; this.y = y; }
Point1.prototype = {
	toString: function() { 
		return "Point1(" + this.x + "," + this.y + ")"; 
	},
	distanceTo: function(p) { 
		var xdiff = p.x - this.x; 
		var ydiff = p.y - this.y; 
		return Math.sqrt(xdiff*xdiff + ydiff*ydiff);
	},
	distanceToOrigin: function() {
		return this.distanceTo({x:0, y:0});
	}
}

var p = new Point1(3,4);
print(p.distanceToOrigin());

quit();

//---------------------------------- 3
// You can give individual instances properties _different_ to those in the prototype
// without affecting any other objects:
var origin = new Point1(0,0);
origin.distanceToOrigin = function() { return "zero"; }

print(p.distanceToOrigin());
print(origin.distanceToOrigin());

quit();

//---------------------------------- 4
// Ok, now create a Circle constructor
// and add methods to the prototype to
// return area and circumference.
// You might want to use Math.PI:

print("Math.PI is " + Math.PI);

























quit();

//---------------------------------- 5
// JavaScript is clearly different in the way it implements the notion
// of _class_ from languages such as Java and C++. The prototype object
// (which corresponds to a class in class-based languages) is an ordinary 
// object! Any object can get to its prototype via the __proto__ field.
//
// One simple consequence of this is the way inheritance can be implemented.
// If you want objects of class B to inherit from class A
// - write constructor functions for A and B as usual
// - define the prototype for A by assigning to the function's prototype property
// - define the prototype for B by assigning to the function's prototype property
// - make the prototype of B's prototype point to A's prototype

function A() {}
A.prototype = {
	foo: function() {
		print("in A::foo()");
	}
}

function B() {}
B.prototype = {
	bar: function() {
		print("in B::bar()");
	}
}
B.prototype.__proto__ = A.prototype;

var b = new B();
b.bar();
b.foo();

quit();

//---------------------------------- 6
// So much for inheriting methods
// What about data?
function AA(name) { this.name = name; }
AA.prototype = {
	foo: function() {
		print("in AA::foo() - name " + this.name);
	}
}

function BB(name, age) {
	AA.call(this,name); 
	this.age=age
}	
BB.prototype = {
	bar: function() {
		print("in BB::bar() - name " + this.name + ", age" + this.age);
	}
}
BB.prototype.__proto__ = AA.prototype;

var bb = new BB("david", 21);
bb.bar();
bb.foo();

// Explain what is happening in the function BB

quit();

//---------------------------------- 7
// So, let's have a Shape hierarchy
// Where Shape has an Origin property inherited by all it's subclasses
// Rectangle has width and height properties
// Circle has radius property
// And both know how to return their area












quit();

// The Classes exploration develops a generally-applicable way of implementing subclassing, which
// doesn't require direct use of the __proto__ field. Knowing what you now know about constructor
// functions and prototypes, can you think how this might work?

//---------------------------------- 8
// Something you need to watch out for is the way JavaScript iterates over members
// in objects with prototypes. It may seem like a neat idea to add methods to 
// Object.prototype so that all objects get some new (possibly default) behaviour.
// Beware of the side effects!

Object.prototype.getKeys = function() {
	var keys = [];
	for (var k in this) {
		keys.push(k);
	}
	return keys;
}

var obj = {foo: 1, bar: 2};
print(obj.getKeys());

quit();
