//--------------------------------------------------------------
// Functions
//(c) 2006 Harvey and Marks. All rights reserved.
//--------------------------------------------------------------

//--------------------------------------------------------------

//---------------------------------- 1
// You know how to write a function, yes?
// Yes, of course you do!

function obvious(x) {
	return x + x;
}
var result = obvious(42);
print("result is " + result);

quit();

//---------------------------------- 2
// But what about this? What's happening here?

var f = function(x) { return x + x; } ;
var result = f(10);

print("result is " + result);

quit();

//---------------------------------- 3
// A brief digression...
// What do you expect to happen here?
function foo1() { print("foo1"); }
var bar1 = foo1;
function foo1() { print("foo1 - again"); }

bar1();
foo1();

quit();

//---------------------------------- 4
// Was it what you expected? How about this?
function foo2() { print("foo2"); }
var bar2 = foo2;
foo2 = function() {print("foo2 - again");}

bar2();
foo2();

quit();

//---------------------------------- 5
// What's the difference? 
// More to the point, _why_ the difference?

//---------------------------------- 6
// So. Back to the point.
// Can you write a function which returns a function?
// Can you write a function which takes a function as a parameter and calls it?
// Can you write a function that 
//	- takes two functions of a single argument, and
//	- returns a single function of a single argument, that
//	- composes the two passed functions into a single function?
// Do it here before scrolling down to a solution





































// Spoiler coming ...

























//---------------------------------- 6 (solution)
// Yes, of course!

/*
function compose(f1, f2) {
	return function(x) { 
		return f2(f1(x));
	}
}

function timesTwo(x) { return x*2; }
function subtractOne(x) { return --x; }

var f = compose(timesTwo, subtractOne);
var result = f(10);

print("result is " + result);
*/
quit();

//----------------------------------
// That was ... intriguing

//---------------------------------- 7
// What do you think happens here?

function foobar(x) {
	var local = x;
	return function(y) { return y * local; }
}

var f1 = foobar(1);
var f2 = foobar(2);
var f3 = foobar(3);

print("f1(10) is " + f1(10));
print("f2(10) is " + f2(10));
print("f3(10) is " + f3(10));

quit();


//---------------------------------- 8
// Could I have written this like this?

function foobar1(x) {
	return function(y) { return y * x; }
}

quit();


//---------------------------------- 9
// Where is local (and x) "remembered"?

//---------------------------------- 10
// OK, so you've got all that. What will happen here then?

function x() {
	function y() {
		return arguments.callee.val;
	}
	return y;
}

var a = x();
var b = x();

a.val = 42
print(a());
print(b());

quit();

// Why?

