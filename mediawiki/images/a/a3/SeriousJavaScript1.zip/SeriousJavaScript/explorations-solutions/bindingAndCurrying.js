/*

Exploring partial application and function currying in JavaScript
============================================================
(Grade - hard)

First of all - some preparatory information...


Working with arguments - a review

Within a function, you can access the arguments
using a special local variable called, by one of
those strange coincidences, "arguments". This is the
way JavaScript deals with variable numbers of 
arguments.

*/
function foo() {
	var s = "foo() called with:";
	for (var i = 0; i < arguments.length; i++) {
		s = s + " ";
		s += arguments[i]; 
	}
	print(s);
}

foo();
foo(1,2,3);
foo(['an', 'array'], {and:'an', o:'bject'});

/*
The arguments object doesn't otherwise
behave like an array, which is inconvenient (it 
doesn't have any of the argument properties and
methods apart from "length"). 

A function can be called using the "normal" call syntax. But
functions are also first-class objects, with methods! You can
call a function using the "call" and "apply" methods.
Both take as an initial parameter an object to use as
"this" in the context of the call. You can pass "undefined" or a
literal empty object to functions which don't reference "this"*.
"Apply" has a second argument which is an array of parameters 
to be passed to the function**: "Call" expects the parameters to be
passed individually:

* (You can implement delegation by passing "this" to a method of another object...!)
** (Apply can also take an arguments object...) 
*/

function xyzzy(a,b) {
	print(this + ", args: " + a + "," + b);
}

xyzzy("called", "normally");
xyzzy.call("Via call", "like", "this");
xyzzy.apply("Via apply", ["and now", "thusly"]);

/*
So ...

1) Write a function "bind1"
	- that takes a function argument (f1) and a single additional argument (a1)
	- that returns a function (f2) which takes one less argument than f1
	- that when called, returns the result of passing f1 the original argument a1 followed by the other arguments to f2
	- like this:

function foo(a,b,c) { ... }
var fooBar = bind1(foo, 3);

-- these should print the same result
-- indeed fooBar should call foo!
print(foo(3,4,5));
print(fooBar(4,5));


2) Write a function "bind" which is similar to bind1, but
	- that takes a function argument (f1) and a variable number of additional arguments (a1..an).
	- that returns a function (f2) which takes n less argument than f1
	- that when called, returns the result of passing f1 the original arguments (a1..an) followed by the other arguments to f2
	- like this:
function foo(a,b,c) { ... }
var fooBinder = binder(foo);

var foo5 = bind(foo, 5);
var foo1and2 = bind(foo, 1, 2);

print(foo(5,6,7));
print(foo5(6,7));

print(foo(1,2,235));
print(foo1and2(235));

This is called "partial application": taking a function and applying it to some arguments to give a function that can be aplied to
the remaining agruments. It is much neater and clearer to write bind(foo, 36) than function(b, c) {return foo(36, b, c);} which
is equivelent.

3) We would generally write a function on two arguments as:

	function add(a, b) {
		return a + b;
	}
	
and call it with add(3, 4). We could equally write:

	function add(a) {
		return function(b) {
			return a + b;
		}
	}

and call it with add(3)(4). This is refferred to as a "curried function" after the logician Haskell Curry. It is the usual form 
in which functions are written in the Haskell programming language (of course the syntax is mucch neater). The advantage with
this form is that you get partial application for free.

Transforming from the first form to the second is called "currying" and vice versa "uncurrying".

In JavaScript, we can be a little more flexible and transform a function into a form that can accept its arguments in whatever 
batches of tuples they come.

Expanding on the previous task, write a function "curry"
	- that takes a function argument (f1) and a variable number of additional arguments (a1) 
	- if that variable number of parameters is greater than or equal to the number of parameters f1 expects, return f1(parameters)
	- otherwise, return a function which calls curry on the function(f1), the additional arguments (a1) and any arguments _it_ is passed
	
For example:
function foo(a,b,c) { ... }

var curriedFoo = curry(foo);

-- these should print the same result
print(foo(10,11,12));
print(curriedFoo(10)(11,12));
print(curriedFoo(10)(11)(12));
print(curriedFoo(10, 11)(12));

Uncurry is less interesting in JavaScript as there is no real reason to write functions in a curried form. You may of course
give it a go.

4) The functions covered so far will not work on methods as the context of the method gets lost when it is passed as an
argument. This is a simple problem to address. Write a function called "bindToObject"
	- that takes a function (most likely a method) and an object and
	- returns a function
	- that has a property "len" set to the value of the "length" property of the original function (see note) and
	- that when called with arguments (args) calls the original function with args and the original object as the "this"
	
NOTE JavaScript functions have a property "length" that indicates the number of arguments expected. Functions that don't 
declare any arguments (because they just use the "arguments" property) have a length of 0. Sometimes, as in the case here, 
you know how many arguments a function expects and want to set the length property. However, it is read only. Our work
around is to set another property "len". We can then modify the curry function, which relies on knowing how many arguments
are required, to check for "len" first. Bit of a hack, but it works.
	
With this hack, functions returned from bindToObject can be partially applied or curried with our existing functions. It is 
also trivial to support partial application in the bindToObject function itself. bindToObject does, of course, have many 
other uses besides partial application and currying.

5) Is there any reason why these functions shouldn't be methods of Function?

*/

// First a utility function to convert arguments (and other things) into an array
var $A =  function(iterable) {
  if (!iterable) return [];
  if (iterable.toArray) {
    return iterable.toArray();
  } else {
    var results = [];
    for (var i = 0, length = iterable.length; i < length; i++)
      results.push(iterable[i]);
    return results;
  }
}

// Next, as you'll likely end up manipulating arrays, you may want to make use of the following:
var a = [1,2,3,4,5];
print(a);
var b = a.shift();
print(a);
print(b);
a.unshift(42);
print(a);

// Finally, a function to mess with 
function average(a,b,c,d) {
	return (a + b + c + d) /4;
}

// 1) ============================ 

function bind1(f, a) {
	return function() {
		var args = $A(arguments);
		args.unshift(a);
		return f.apply({}, args);
	}
}

var averageWith2 = bind(average,2);
print(averageWith2(4, 6, 8));

// 2) ============================ 

function bind() {
	var args = $A(arguments);
	var f = args.shift();
	return function() {
		return f.apply({}, args.concat($A(arguments)));
	}
}

print(bind(average, 2)(4, 6, 8));
print(bind(average, 2, 4)(6, 8));

// 3) ============================ 

function curry() {
	var args = $A(arguments);
	var f = args.shift();
	if (args.length >= (f.len || f.length)) {
		return f.apply({}, args);
	} else {
		return function() {
			return curry.apply({}, [f].concat(args).concat($A(arguments)));
		}
	}
}

print(curry(average)(1)(2)(3)(4));
print(curry(average, 1)(2)(3)(4));
print(curry(average, 1, 2)(3, 4));

// 4) ============================ 

function bindToObject(f, o) {
	var bound = function() {
		return f.apply(o, arguments);
	};
	bound.len = f.length;
	return bound;
}

var obj = {x: 42, foo: function(y, z) {return this.x + y + z;}};
print(curry(bindToObject(obj.foo, obj))(3)(5));

// 5) ============================ 

// Not that we can think of, but we haven't tried it.
