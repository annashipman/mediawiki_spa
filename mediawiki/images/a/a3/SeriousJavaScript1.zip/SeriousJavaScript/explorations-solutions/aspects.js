/*

Aspect-oriented programming in JavaScript
========================================
(Grade - moderate to hard)

1) Can you replace a method on an object with another one?

2) Can the new method call the old one?

3) Can you fix it so that when you call method on an object, you can specify code to 
    execute before the original code is called?
   - how will you pass it the original object's arguments and "this"?
   - can you let the inserted code know what the old method is called (might be useful for logging)?

4) Can you fix it so that when you call method foo on an object, you can specify code to 
    execute after the original code is called?
   - how will you ensure that you return the return value of the original method to the caller?
   - can you make that return value available to the inserted code?
   - can you tell the inserted code whether it's executing before or after the original method?

5) Can you fix it so that you can insert the before/after code described above
   - on an individual object?
   - for all objects of a given class?

6) Can you fix it so that you can add code to be called _around_ the invocation of a method?
   - this is harder
   - in the around code, you'll need a standard way of invoking the wrapped method
   - you'll need to pick apart the code for the method and change it
      * Object.toSource will return the compilable source code of any object (including a function) as a string
      * new Function([arg-name,]* source) will return a function object:
          var f = new Function("x" "return x*x;");

7) - can you fix it so that you can wrap an already-wrapped method?

*/

var errorPrototype= {
	toString: function() {
		return this.name + ": " + this.message;
	}
}

function BadAspectError(message) {
	this.name="BadAspectError";
	this.message=message;
}
BadAspectError.prototype = errorPrototype;

function NotAMethodError(message) {
	this.name="NotAMethodError";
	this.message=message;
}
NotAMethodError.prototype = errorPrototype;

function NoSuchMethodError(message) {
	this.name="NoSuchMethodError";
	this.message=message;
}
NoSuchMethodError.prototype = errorPrototype;

Object.extend = function(object, methods) {
	for (x in methods) {object[x] = methods[x]; }		
}

var AspectMixin = {
	check:  function(aspect, methodName) {
		if (typeof(aspect) != 'function') {
			throw new BadAspectError(aspect);
		}
		var target = this;
		if (target instanceof Function) {
			target = target.prototype;
		}
		if (!target[methodName]) {
			throw new NoSuchMethodError(methodName);
		}
		if (!(target[methodName] instanceof Function)) {
			throw new NotAMethodError(methodName);
		}
		return target;
	},

	addBefore: function(aspect, methodName) {
		var target = this.check(aspect, methodName);
		var old = target[methodName];
		target[methodName] = function() {
			this.aspect = {};
			this.aspect._methodName = methodName;
			this.aspect._when = "before";
			aspect.apply(this, arguments);
			return old.apply(this, arguments);
		}
	},

	addAfter: function(aspect, methodName) {
		var target = this.check(aspect, methodName);
		var old = target[methodName];
		target[methodName] = function() {
			this.aspect = {};
			this.aspect._methodName = methodName;
			this.aspect._when = "after";
			var ret = old.apply(this, arguments);
			this.aspect._ret = ret;
			aspect.apply(this, arguments);
			delete this.aspect_ret;
			return ret;
		};
	},
	
	addAround: function(aspect, methodName) {
		var target = this.check(aspect, methodName);
		var callname = "_orig_" + methodName;
		target[callname] = target[callname] || [];
		var callIndex = target[callname].length;
		target[callname][callIndex] = target[methodName];
		var src = aspect.toSource();
		// remove the function() and the surrounding "()"
		src = src.substring(src.indexOf("{"),src.length-1);
		// replace the call to proceed() by applying the args to the saved original method
		src = src.replace("proceed()", "this."+callname+"[" + callIndex + "].apply(this,arguments)");
		// set the methodname for the duration of the call
		src = "this.aspect._methodName = \"" + methodName + "\"; " + src;
		src = "this.aspect = {};" + src; 
		// turn it into a new method on the target object
		target[methodName] = new Function(src);
	},
};


Point = function(x,y) { this.x = x; this.y = y; };

Point.prototype  = {
	set: 			function(x,y) 	{ this.x = x;  this.y = y;  return this; },
	move:		function(x,y) 	{ this.x += x;  this.y += y;  return this; },
	distanceFrom:	function(x,y) 	{ var xd = this.x-x; var yd=this.y-y; return Math.sqrt(xd*xd + yd*yd); },
	toString:		function() 	{ return "Point("+this.x+"," + this.y + ")"; },
}

// To implement aspects at a class and/or instance level, extend either the constructor function (class) 
// or the constructor functions's prototype (instance) respectively:

Object.extend(Point, AspectMixin);
Object.extend(Point.prototype, AspectMixin);

log = function() {
	var args = "";
	for (var i = 0; i < arguments.length;i++) {
		if (i>0) args +=",";
		args+=arguments[i];
	}
	print(this.aspect._when + " " + this.aspect._methodName + "(" + args + ") "
		+ "on " + this.toString()
		+ (this.aspect._when == "after" ? ", returning " + this.aspect._ret : "")
	);
}

wrap = function() {
	print("Before " + this.aspect._methodName + " on " + this);
	var ret = proceed();
	print("After " + this.aspect._methodName + " on " + this);
	return ret;
}

p = new Point(10,20);
p1 = new Point(100,300);

print(p);
p.set(30,40);
print(p);

Point.addBefore(log , "set");
p.set(-1,-2);
print(p);

p.move(10,10);
p.addAfter(log , "move");
p.move(-5,5);
p1.set(38,56);
p1.move(10,10);

print(p1.distanceFrom(0,0));

Point.addAround(wrap,"distanceFrom");

print(p1.distanceFrom(3,4));

Point.addAround(wrap,"distanceFrom");

print(p1.distanceFrom(9,4));

try {
	Point.addBefore(123, "distanceFrom");
} catch (e) {
	print(e);
}

try {
	Point.addBefore(log, "foo");
} catch (e) {
	print(e);
}

try {
	p = new Point(10,10);
	p.addBefore(log, "x");
} catch (e) {
	print(e);
}
