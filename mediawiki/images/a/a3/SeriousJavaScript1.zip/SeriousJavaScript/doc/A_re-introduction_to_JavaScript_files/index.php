/* generated javascript */var skin = 'devmo';
var stylepath = '/en/docs/skins';/* MediaWiki:Devmo */
