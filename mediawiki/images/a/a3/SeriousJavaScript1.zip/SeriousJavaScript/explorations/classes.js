/*

Implement classes in JavaScript
==============================
(Grade - moderate to hard)

There are no explicit classes in JavaScript - only constructor functions and their prototypes.

This exploration develops a class abstraction to allow us to more easily express "standard" object-oriented
designs directly.

Our goal is to be able to create subclasses easily. The problem is that with JavaScript's prototype based
model. When we create an objet to act as a subclass it gets initialized as an instance. Apart from initializing
members that should not be initialized, this may also cause unwanted side effects such as IO.

Getting round this is somewhat tricky, so we are going to take it in small steps. Alternatively, feel free to jump right
in and skip to step 5 below.

NOTE there is a much simpler solution using the non-standard and deprecated __proto__ property, but that would 
be non-standard and deprecated... and nowhere near as much fun.

1) Let's assume that we'll define a method "initialize" for every class we write. Cany you write a JavaScript constructor
function that will call initialize, passing on its arguments?

2) Now generalize that into a factory that takes the prototype as an argument. Add it as a "static method" of Object
so we can write:

	var MyNewClass = Object.createConstructor(prototype);
	var x = new MyNewClass("some", "parameters");
	
Might be an idea to guard the call to initialize in case the prototype given doesn't have such a method. 

This factory is useful in itself in that it gives us a neat way to define new classes, but it doesn't allow us to subclass
yet. We'll come back to it shortly.

Note that we would have prefered to add this as a method of Object.prototype so we could just say
myPrototype.createConstructor(). We did not do that because of the impact on iterating members of objects mentioned
earlier. The same is also true for the next few utility methods.

3) Create another static method on Object called "extend". Extend should take two objects as arguments and copy all
the members of the second to the first.

This is also useful in its own right as it allows us to neatly do mixins.

4) Add one more static method to Object, "derive". This takes two objects and returns a new object whose prototype is
the first and has a copy of all the methods of the second. You'll need to call extend, but createConstructor is not quite
right for this. Don't change createConstructor as you'll need it in the next step.

Derive allows us to "subinstance" objects and can be used where only one instance is required. Bye bye Singleton pattern.

5) Now, we have all the pieces we need to write the subclass method. Add a method to Function.prototype called
"subclass". It should take an object with all the methods to add to our subclass and should return a constructor for
a subclass of the reciever's prototype. When you are done, you should be able to run the code below.
*/

quit(); // comment out the quit when you get to here

var Foo = Object.subclass({
	initialize: function() {print("initialize in Foo");},
});

var Bar = Foo.subclass({
	initialize: function() {
		print("initialize in Bar");
		Foo.prototype.initialize.call(this);
	}
});

// Should output "initialize in Bar" then "initialize in Foo".
// Must not output "initialize in Foo" when the subclass is created above.
var bar = new Bar();

// When you add a method to Foo.prototype, it should be accessible to bar instances.
Foo.prototype.blat = function() {print("blat");}
bar.blat();