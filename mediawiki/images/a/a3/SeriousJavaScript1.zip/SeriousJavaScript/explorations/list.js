/*

Implement a "classic" list in JavaScript
=====================================
(Grade - moderate)

JavaScript has objects and arrays, but no lists.

A list is 
	- the empty list []
	- or the concatenation of an item (head) and a list (tail) [ a . L ]
	- has methods
		- head, which returns the first element
		- tail, which returns the tail list 
		- length, which returns its length
		- cons, which takes a single argument and returns a new list whose head is the argument and tail is "this"
		- toString, which returns a string representation
		
Supplementary (1): implement "class" methods on List to build a list
	- from an array
	- from a variable number of passed arguments

Supplementary (2): implement the following list methods
	- append, which returns a new list from the elements of this followed by the elements of the second
	- toArray, returns an array representaiton of the list's elements
	- map, which takes a function parameter and calls that parameter on each element of the list, building a list from the return
	values. Function takes one parameter, the list item.
	- fold, which takes a function and an initial value for an accumulator, and
		calls the function  passing the accumulator and first element
		cals the function on each subsequent element, passing 
			the value returned from the previous call as the new accumulator 
			the list element itself
	- forEach, which takes a function parameter and calls that parameter on each element of the list, with arguments
		item: the list item
		index: the number of the item (0-based)
		list: the entire list
*/


//----------------------------------------------------------------------------------------------------
// Here's a utility function to convert arguments (and other things) into an array
var $A =  function(iterable) {
  if (!iterable) return [];
  if (iterable.toArray) {
    return iterable.toArray();
  } else {
    var results = [];
    for (var i = 0, length = iterable.length; i < length; i++)
      results.push(iterable[i]);
    return results;
  }
}

