/*

Exploring Monads in JavaScript
============================================================
(Grade - hard)

Monads are a concept from Category theory in mathematics. They are used in the Haskell programming
language as a way of wrapping data through a computation and as a way of abstracting operations on
computations. We are not going to get into the mathematical concept at all here, but will look at how
monads apply to programming (how they are used in languages such as Haskell).

It should be noted that in general, the problems that monads have been used to solve are not really
problems that occur in JavaScript. The most common use is to allow side-effecting operations, such as
IO, to be performed in a pure functional language without any compromise of the model or risk of
inconsistency. In an imperative language such as JavaScript there is no need for such a construct. 
The purpose of this exercise is 1) to explain monads in a context that is vaguely familiar to most
developers; and 2) to demonstrate that you can do some pretty wild stuff in JavaScript.

Note also that in our work below there will be no "thing" called a monad. Monads exist in the domain
of types and JavaScript code does not directly express types. What we are doing here is inventing a
protocol, creating classes that implement that protocol and building generic operations that act
on instances of such classes.

We will start by looking at two things that are in fact monads. We will introduce them independently
then look at the monad abstraction. We'll then get you to write some operations on monads. Finally 
we'll introduce a third monad.

Maybe
-------
For any type X, Maybe X is a type whose values will either hold a value of type X or be nothing. An 
example may help. Some values of type Integer are 0, 1 and 42. Some values of type Maybe Integer
are Just(0), Just(1), Just(42) and nothing.

Why is this interesting? In a staticallly typed language (like Java or Haskell) this is very useful
as it allows us to pass about values that may be unavailable. In JavaScript we don't have this problem
becuse values we pass around can be of any type so we could use integers sometimes and, say, 
undefined at other times.

However, suppose you had a function that usually returned numbers, but somtimes had to return a 
special value indicating that, for a given argument, there was no value to return. An example might 
be calculating square roots where there is no value to return for negative arguments. In JavaScript
you could make such a function throw an exception. Alternatively, we could return a undefined or 
some other special value. Either way, you would have to write some code to deal with this case before
passing the value on to another calculation. For example:

function sqrt(x) {
	if (x < 0) return undefined;
	Math.sqrt(x);
}

function twiceSqrt(x) {
	var y = sqrt(x);
	if (y == undefined) return undefined;
	return x * 2;
}

In twiceSqrt, we have to check the return from sqrt before passing it to * else an exception would
be thrown. It would be neater if the undefined value just propogated.

Actually JavaScript already handles this for numbers using NaN. NaN stands for "Not a Number".
When any operand of a numeric operator is NaN, the result is NaN, so we could just use that.
However, this mechanism does not extend to values other than numbers such as strings or objects.
Althouth we are using numbers in this example, our solution works for all types.

So let's design a Maybe type that makes this neat.
*/


function task1() {
// We've put this in a function to isolate it from the rest of the file
print("--- Task 1 ---");

//As there is only one nothing we will represent it as an object rather than a class:
var nothing = {
	hasValue: 	function() 	{ return false; },
	value: 	function() 	{ throw new Error('"Nothing" never has a value...'); },
	toString: 	function() 	{ return "nothing"; },
}

// Things which do have values wrapped in an object
function Just(value) { this.val = value; }
Just.prototype = {
	hasValue:	function() 	{ return true; },
	value:	function() 	{ return this.val; },
	toString: 	function() 	{ return "Just(" + this.val + ")"; }
}

// A utility function that wraps a value in a Maybe
function just(x) { return new Just(x); }

/* 
1) Rewrite the function sqrt from the introduction so that
	- it takes a single numeric  argument
	- returns nothing if the argument is negative
	- returns a Maybe containing the square root of the argument otherwise

Then write a function timesTwo that
	- takes a single numeric  argument
	- returns a Maybe containing it's argument times two

Then write a function sqrtTimesTwo combining these two functions that
	- takes a single numeric argument
	- returns a Maybe

Test these by calling them with positive and negative values
*/

// Write your solution here...




}

task1();
quit();

// NB when you've finished this task, comment out the two lines above


/*
All well and good, but as it stands the code in sqrtTimesTwo is no neater, really.

Let's extend the Maybe type with two methods:

	- "then", which takes a function as a parameter. This function must take a single 
	  parameter and return a Maybe. For nothing, bind ignores the function and 
	  simply returns itself. For a Just, bind calls this function with its value, and
	  returns the result. This function can be used to chain operations together,
	  such that if any operation cannot be performed the result of the whole
	  chain is nothing.
	
	- "or", which takes a Maybe as a parameter. For nothing, "or" returns the passed 
	  Maybe; for a Just, "or" returns itself. This method allows us to provide an
	  alternative in the chain of computations should a prior computation result in
	  nothing
*/
function task2and3() {
// We've put this in a function to isolate it from the rest of the file
print("--- Task 2 & 3 ---");

var nothing = {
	hasValue: 	function() 	{ return false; },
	value: 	function() 	{ throw new Error('"Nothing" never has a value...'); },
	then: 	function(f)	{ return this; },
	or:		function(m)	{ return m; },
	toString: 	function() 	{ return "nothing"; },
}

function Just(value) { this.val = value; }
Just.prototype = {
	hasValue:	function() 	{ return true; },
	value:	function() 	{ return this.val; },
	then:	 	function(f)	{ return f(this.val); },
	or:		function(m)	{ return this; },
	toString: 	function() 	{ return "Just(" + this.val + ")"; }
}

function just(x) { return new Just(x); }


/*
2) Firstly, copy your  sqrt and timesTwo functions from task1() to here. Then rewrite 
sqrtTimesTwo using then to sequence the operations. Test this!

*/

// Write your solution here...

/*
3) Now write a function sqrtOrBust which
	- takes a single numeric argument
	- returns the square root of the argument as a Maybe, if it
	  can be calculated, or a Maybe with the string "bust" if not
*/

// Write your solution here...

}

task2and3();
quit();
// NB when you've finished this task, comment out the two lines above


/*
We will return to Maybe shortly; but now, let's play with Arrays...

Below, we've added a method to the Array prototype:

	- "flatMap" takes a function as an argument, this function must take a single argument
	  and return an array. flatMap calls this function for each element in the array, and 
	  returns a concatenation of the results
*/

function task4() {
// We've put this in a function to isolate it from the rest of the file
print("--- Task 4 ---");

Array.prototype.flatMap = function(f) {
	var result = [];
	for(var i = 0; i < this.length; i++) {
		result = result.concat(f(this[i]));
	}
	return result;
}

/*
4) Write a function named "expand", using flatMap and concat, that 
	- takes an array of numbers
	- returns an array with each number duplicated it's number of times, with
	  a zero added on the end
	[2,1,4] => [2,2,1,4,4,4,4,0]
*/

// Write your solution here...

}

task4();
quit();
// NB when you've finished this task, comment out the two lines above

/*
We're now going to return to Maybe, and make some modifications. The reason for these
changes will become clear shortly. We have

	- renamed "then" to "bind"
	- renamed "or" to "plus"
	- added an extra parameter to the function called by bind, so that now it is given
	  a  "class" (i.e. a constructor function)
	- added a class function ret which creates a Maybe for its given value
	- added a class function zero which returns nothing
*/

function task5to8() {
// We've put this in a function to isolate it from the rest of the file
print("--- Task 5 to 8 ---");

var nothing = {
	hasValue: 	function() 	{ return false; },
	value: 	function() 	{ throw new Error('"Nothing" never has a value...'); },
	bind: 	function(f)	{ return this; },
	plus:		function(m)	{ return m; },
	toString: 	function() 	{ return "nothing"; },
}

function Just(value) { this.val = value; }
Just.prototype = {
	hasValue:	function() 	{ return true; },
	value:	function() 	{ return this.val; },
	bind:	 	function(f)	{ return f(Just, this.val); },
	plus:		function(m)	{ return this; },
	toString: 	function() 	{ return "Just(" + this.val + ")"; }
}

function just(x) { return new Just(x); }

Just.zero = function() {return nothing;};
Just.ret = just;

/*
5) Copy your definitions of sqrt, timesTwo, sqrtTimesTwo and sqrtOrBust from earlier.
Modify these to work with the modified Maybe definitions, and in sqrt and timesTwo to
use zero and ret from the passed-in class
*/

// Write your solution here...

/*
Now we'll modify Array in a similar way:
	- flatMap becomes bind, and the passed function takes an additional initial 
	  parameter, the class implementing "ret" and "zero"
	- we've added a method "pls method "reus", which is a simple alias for concat 
	- we've added a class method "ret", which returns an array whose single element 
	  is the given argument
	- and a class method "zero", which returns an empty array
*/

Array.prototype.bind = function(f) {
	var result = [];
	for(var i = 0; i < this.length; i++) {
		result = result.concat(f(Array, this[i]));
	}
	return result;
}
Array.prototype.plus = Array.prototype.concat;
Array.zero = function() {return [];}
Array.ret = function(x) {return [x];}

/*
6) Copy the function "expand" you wrote in task 4, and modify it to work 
with the new Array methods.
*/

/*
Now for the magic. This is what all this has been building up to.
(Roll of drums, please...)

7) Uncomment the line of code below and run it
*/

//print([4,9,16].bind(sqrt).bind(timesTwo).plus([5,6]));

/*
Tadaaa!!!

In case you missed it, what we've done is use the functions we wrote to work
with Maybes against an Array. To make this work we've abstracted the
commonality between the two types and written functions so that they
are parameterised by the type. This commonality _is_ the Monad protocol.
Actually, it is useful to split this down into two parts:

	- bind and ret (usually called return) are the Monad protocol
	- zero and plus are MonadPlus
	
To conform to these protocols, the implementations of these methods must obey
certain rules - discussion of these is beyond the scope of this tutorial, but you
should now be in a position to understand them.

There are many types which conform to Monad, but not to MonadPlus.

Note that in Haskell Monad and MonadPlus are coded as classes of types,
whereas here they are merely protocols.

Note also that Haskell's compiler is able to deduce what type general Monadic 
functions are applied to, and introduces the extra type parameter (which we've 
made explicit) behind the scenes.

Be aware that sqrt and timesTwo are functions that act on any Monadic type, 
whereas others may be tied to a specific monad, just as some array operations 
work on arrays containing any type, whereas others only work with arrays of 
(say) numbers.
*/

/*
To finish, we'll introduce a third Monad. In Haskell Monads are commonly used
to implement combinators. These build compound operations out of simpler ones.
Often this is used to sequence operations and isolate code from state changes.

The Writer class below builds sequences of operations that perform output. Note
that the things being assembled here are the operations not the output itself. The
operations only get executed when run() is called on them.
*/

var Writer = function(run) {this.run = run}
Writer.prototype = {
	bind: function(f) {
		var runMe = this.run;
		return new Writer(function() {return f(Writer, runMe()).run();});
	}
}
Writer.ret = function(x) {return new Writer(function() {return x;});}

function write(W, x) {return new Writer(function () {print(x);});}

/*
As you can see, Writer implements Monad but not MonadPlus - there is no plus operation
on Writers (though you could implement zero).

8) Use the Writer monad to output the square root of 9.
*/

// Write your solution here...

/*
In a pure functional language like Haskell, this is the only way to deal with IO (of course it
offers a much neater syntax). This is because in these languages, as order of evaluation is 
undefined, it is essential that a function only depends on its arguments. Doing IO functionally
would mean that a function could return a different result depending on what operations had
gone before. Using monads like Writer avoids this.

In JavaScript you could have just written print(Math.sqrt(9)), but where's the fun in that?
*/

}

task5to8();


