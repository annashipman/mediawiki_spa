/*

Using closures to implement objects
=================================
(Grade - easy)


1) Can you write a function called account which
    - takes a single parameter called b
    - returns a function (let's call it M) of no arguments which returns the value b

2) Now change the function M so that it
    - takes a single parameter
    - updates b by adding the parameter
    - returns the new b

Is this a little like objects? Yes!

3) Change account so that it returns an object with a single method called deposit that is exacly 
the same as M in 2 above, but doesn't return anything. Add another method called withdraw that 
deducts its parameter from b. Add another called balance that returns b.

Congratulations! You've implemented an object programming model! Note that it enforces
encapsulation which JavaScript's object model does not.

What is the downside of this model?

*/