/*

More Functional Abstracion
==========================
Grade - easy

(1) Write a function to add all the elements of a non-empty array
*/

var a = [ 1, 10, 100, 1000 ];

function addAll(a) {
	var total = 0;
	for (var index = 0; index < a.length; index++) {
		total = total + a[index];
	}
	return total;
}

print(addAll(a));

/*
(2) Now write a function to multiply all the elements of a non-empty array
*/

function mulAll(a) {
	var total = 1;
	for (var index = 0; index < a.length; index++) {
		total = total * a[index];
	}
	return total;
}

print(mulAll(a));

/*
// (3) These look very similar ... 
// Write a function "accumulate" which
// - takes a non-empty array argument A, a function argument f and an identity argument i
// - function f takes the current accumulated value and a next value from the array, and 
// returns the accumulation (however defined) of the current accumulated value plus
// some function of the next valye
// - i is the initial accumulated value
// - returns the final accumulated value
// Use the function to implement 
// - sum
// - product
// - sum of squares
// - product of reciprocals
*/

function accumulate(a, f, i) {
	for (var index = 0; index < a.length; index++) {
		i = f(i,a[index]);
	}
	return i;
}

var x = accumulate(a, function(acc,next) { return acc + next; }, 0);
print(x);
var x = accumulate(a, function(acc,next) { return acc * next; }, 1);
print(x);
var x = accumulate(a, function(acc,next) { return acc + next*next; }, 0);
print(x);
var x = accumulate(a, function(acc,next) { return acc / next; }, 1);
print(x);

/*
Two different ways to take this: firstly
(4) Write a function which takes a function argument f and an identity i, which...
	...returns a function which, when called on an array...
	...accumulates according to the function and identity as described above
*/

function accumulator(f, i) {
	return function (a) {
	for (var index = 0; index < a.length; index++) {
			i = f(i,a[index]);
		}
		return i;
	}
}

print (a);
var summer = accumulator(function(acc,next) { return acc + next; }, 0);
print(summer(a));
var multiplier = accumulator(function(acc,next) { return acc * next; }, 1);
print(multiplier(a));

/*
 .. secondly, go back to the function you wrote in (3). It takes an array as an initial parameter, so
 (5) Make the function you wrote in (3) a method on Array.
*/

/*
 (6) Implement other methods on array, such as
	each(function) - calls function on each element of the array in turn
	collect(function) - returns an array whose elements are the return values of the passed function called on each array element
	all(function) - returns true if the result of calling function on all elements of the array is true
	any(function) - returns true if the result of calling function on any element of the array is true
	detect(function) - returns the first value in the array for which calling function on that value returns true
	select(function) - returns an array containing all the values from the original array for which the function returns true
	reject(function) - returns an array containing all the values from the original array for which the function returns false
	
In each case the function passed will be called with two arguments: the value of the array item itself, and the index position of the item in the array.

Can you take advantage of the common structure of each of these functions to implement them by calling a simpler iterating method?

*/