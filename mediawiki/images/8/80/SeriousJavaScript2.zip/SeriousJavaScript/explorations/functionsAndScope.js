/*

Exploring functions and scope
============================
(Grade - easy)

Based on Abelson/Sussman, SICP - 1.1.7

Newton's method for finding square roots - relies on the fact that if a guess G is an
approximation to the square root of a number N, then a better approximation
is (G + N/G)/2.

(1) Write a function or set of functions functions that implements this method. 

(2) One function or many? If you've written a big lump of code :-) try breaking it down into a main function
and helper functions:
- sqrt(n): calls functions as below
- goodenough(guess,n) - return true if guess*guess is close enough to n (you'll need Math.abs for this)
- improve(guess,n) - returns an improved guess as described above
- sqrtiter(guess,n) - if guess is good enough, return guess, otherwise improve the guess and try again

(3) JavaScript has Lexical scope - so you can define a function inside another function, to make its name
local to the enclosing function, as in the example below.  Rewrite (2) so that all the helper functions are 
local to the main function
*/

function foo(x) {
	function foo_helper(y,z) {
		return y*z;
	}
	return foo_helper(x,3);
}
print(foo(12));

/*
(4) Another consequence of lexical scope is that parameters and variables in scope in an enclosing 
function are in scope in enclosed functions: so the example above could be re-written as below. 
Rewrite (3) using the enclosing function's parameter.
*/

function foo1(x) {
	function foo_helper(z) {
		return x*z;
	}
	return foo_helper(3);
}
print(foo(12));

