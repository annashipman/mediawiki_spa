/*

Aspect-oriented programming in JavaScript
========================================
(Grade - moderate to hard)

1) Can you replace a method on an object with another one?

2) Can the new method call the old one?

3) Can you fix it so that when you call method on an object, you can specify code to 
    execute before the original code is called?
   - how will you pass it the original object's arguments and "this"?
   - can you let the inserted code know what the old method is called (might be useful for logging)?

4) Can you fix it so that when you call method foo on an object, you can specify code to 
    execute after the original code is called?
   - how will you ensure that you return the return value of the original method to the caller?
   - can you make that return value available to the inserted code?
   - can you tell the inserted code whether it's executing before or after the original method?

5) Can you fix it so that you can insert the before/after code described above
   - on an individual object?
   - for all objects of a given class?

6) Can you fix it so that you can add code to be called _around_ the invocation of a method?
   - this is harder
   - in the around code, you'll need a standard way of invoking the wrapped method
   - you'll need to pick apart the code for the method and change it
      * Object.toSource will return the compilable source code of any object (including a function) as a string
      * new Function([arg-name,]* source) will return a function object:
          var f = new Function("x" "return x*x;");

7) - can you fix it so that you can wrap an already-wrapped method?

*/
