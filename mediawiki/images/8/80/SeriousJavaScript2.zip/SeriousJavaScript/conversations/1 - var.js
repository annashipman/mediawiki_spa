//--------------------------------------------------------------
// Variables
//(c) 2006 Harvey and Marks. All rights reserved.
//--------------------------------------------------------------
//--------------------------------------------------------------
// Variables
//
// A little playground for experimenting with scope
// Each exercise: predict, try, reflect.
// Comment out the quit after each one to continue.
// What have you learned about JavaScript scope?
//(c) 2006 Harvey and Marks. All rights reserved.
//--------------------------------------------------------------

//---------------------------------- 1
x = 1;
print(x);
// What will this print?

quit();

//---------------------------------- 2
//w;
//print (w);
// What will this print?
// Why is this commented out?
// (Hint - try uncommenting it ... )
quit();

//---------------------------------- 3
var y;
print (y);
// What will this print?

quit();

//---------------------------------- 4
print (yy);
var yy;
// What will this print?

quit();


//---------------------------------- 5
y = 1;
print (y);
// What will this print?

quit();

//---------------------------------- 6
function foo(x) {
	print("In foo - x(1) is " + x);
	x = 69;
	print("In foo - x(2) is " + x);
}

foo(42);
// What will this print?

quit();

//---------------------------------- 7
print("after foo() - x is now " + x)
// What will this print?

quit();

//---------------------------------- 8
function bar() {
	print("In bar - x(1) is " + x);
	x = 99;
	print("In bar - x(2) is " + x);
}

bar();
// What will this print?

quit();

//---------------------------------- 9
print("after bar() - x is now " + x);
// What will this print?

quit();

//---------------------------------- 10
function snafu() {
	print("In snafu - x(1) is " + x);
	var x = 66;
	print("In snafu - x(2) is " + x);
}

snafu();
// What will this print?

quit();

//---------------------------------- 11
print("after snafu() - x is now " + x);
// What will this print?

quit();

//---------------------------------- 12
function wibble() {
	z = 1001;
	print("In wibble - z is " + z);
}

wibble();
// What will this print?

quit();

//---------------------------------- 13
print("after wibble() - z is now " + z);
// What will this print?

quit();

//---------------------------------- 14
function hoopy() {
	var xyzzy = 2002;
	print("In hoopy - xyzzy is " + xyzzy);
}

hoopy();
// What will this print?

quit();

//---------------------------------- 15
print("after hoopy() - xyzzy is now " + xyzzy);
//What will this print?
