//--------------------------------------------------------------
// ObjectsAndArrays
//(c) 2006 Harvey and Marks. All rights reserved.
//--------------------------------------------------------------

//---------------------------------- 1
// Basic array manipulation

var a = [];
// var a = new Array() also works 
a[0] = "hello";
a[1] = 1.234;
a[2] = { x:100, y:200 };

print(a);

quit();

//---------------------------------- 2
// What do you think happens here?
a[5] = "past the end?";

print(a);

quit();

//---------------------------------- 3
// How long is an array?
print(a.length);

quit();

//---------------------------------- 4
// Accessing each element 
for (var i = 0; i < a.length; i++) {
	print(a[i]);
}

quit();

// Did you spot the undefined elements? Why are these elements undefined?

//---------------------------------- 5
// What about an object?
// There are 2 different forms of the "for" statement for objects
var o = {x:100, y:200, z:300};

// for ... in gets keys
for (var i in o) {
	print(i + ": " + o[i]);
}

// for each ... gets values
for each (var i in o) {
	print(i)
}

//---------------------------------- 6
// You might be tempted to try this on an array ....
// What problems might arise?

// Hint - an array is of course just an object
var extendedArray = ['a','b','c'];
extendedArray.name = "an extended array...";

// What will this print?
for (var i in extendedArray) {
	print(i + ": " + extendedArray[i]);
}

// That's right!

quit();
